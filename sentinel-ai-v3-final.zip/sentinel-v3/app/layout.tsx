import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Vault Sentinel — AI Audit & Deepfake Analysis',
  description: 'Enterprise-grade AI integrity verification and deepfake detection',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=Share+Tech+Mono&family=Exo+2:wght@300;400;500;600&display=swap" rel="stylesheet" />
      </head>
      <body className="antialiased scanline-fx ambient-bg" style={{ fontFamily: "'Syne', sans-serif" }}>
        {children}
      </body>
    </html>
  )
}
