"use client"

import { useState, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Sparkles, Send, Rocket } from "lucide-react"
import { Header } from "@/components/sentinel/header"
import { Sidebar } from "@/components/sentinel/sidebar"
import { DetectionHub } from "@/components/sentinel/detection-hub"
import { ProcessLog, LogStep } from "@/components/sentinel/process-log"
import { AuditAnalytics } from "@/components/sentinel/audit-analytics"
import { CertificationCard } from "@/components/sentinel/certification-card"
import { DiagnosticsPanel } from "@/components/sentinel/diagnostics-panel"
import { CompanyWorkspace } from "@/components/sentinel/company-workspace"
import { DimensionScores } from "@/components/sentinel/dimension-scores"

type TabType = "video" | "audio" | "image" | "file"
type Mode = "deepfake" | "ai-audit"

const initialRadar = { bias: 20, accuracy: 20, safety: 20, transparency: 20, privacy: 20 }

const SCAN_STEPS: Omit<LogStep, "id">[] = [
  { timestamp: "00:42:12", title: "Step 1:", description: "Frame-by-frame neural decomposition initiated...", status: "completed" },
  { timestamp: "00:42:15", title: "Step 2:", description: "Eyeblink rate verified (4 BPM) —", status: "alert", alertType: "red", alertText: "Red Alert: Artifact detected." },
  { timestamp: "00:42:18", title: "Step 3:", description: "Lip-sync phase-shift analysis in progress...", status: "running" },
  { timestamp: "PENDING",  title: "Step 4:", description: "Deep spectral audio fingerprinting...", status: "pending" },
  { timestamp: "QUEUED",   title: "Step 5:", description: "Metadata authenticity verification...", status: "queued" },
]

const DIAGNOSTICS = [
  { type: "SYS" as const, message: "Kernel monitoring active..." },
  { type: "SEC" as const, message: "Vault encryption verified." },
  { type: "AUD" as const, message: "Awaiting payload injection." },
]

export default function SentinelAuditor() {
  const [mode, setMode] = useState<Mode>("deepfake")
  const [activeNav, setActiveNav] = useState("dashboard")
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [authenticityScore, setAuthenticityScore] = useState(0)
  const [threatLevel, setThreatLevel] = useState<"Low" | "Medium" | "High">("Low")
  const [radarData, setRadarData] = useState(initialRadar)
  const [certStatus, setCertStatus] = useState<"pass" | "fail" | "pending">("pending")
  const [processLogs, setProcessLogs] = useState<LogStep[]>([])
  const [chatMessage, setChatMessage] = useState("")
  const [dimScores, setDimScores] = useState({ bias: 87, safety: 94, performance: 78 })

  const handleFileSelect = useCallback((file: File | null, _type?: TabType) => {
    setSelectedFile(file)
    setCertStatus("pending")
    setProcessLogs([])
    setAuthenticityScore(0)
  }, [])

  const runAudit = useCallback(async () => {
    if (!selectedFile) return
    setIsAnalyzing(true)
    setCertStatus("pending")
    setProcessLogs([])

    for (let i = 0; i < SCAN_STEPS.length; i++) {
      await new Promise(r => setTimeout(r, 800))
      setProcessLogs(prev => {
        const logs = [...prev]
        if (logs.length > 0 && logs[logs.length - 1].status === "running") {
          logs[logs.length - 1] = { ...logs[logs.length - 1], status: "completed" }
        }
        const step = SCAN_STEPS[i]
        logs.push({ ...step, id: `step-${i}`, status: i === SCAN_STEPS.length - 1 ? "running" : step.status })
        return logs
      })
      const progress = (i + 1) / SCAN_STEPS.length
      setAuthenticityScore(Math.floor(60 + Math.random() * 35 * progress))
      setRadarData({
        bias: 30 + Math.random() * 60 * progress,
        accuracy: 40 + Math.random() * 55 * progress,
        safety: 35 + Math.random() * 60 * progress,
        transparency: 25 + Math.random() * 70 * progress,
        privacy: 45 + Math.random() * 50 * progress,
      })
    }

    await new Promise(r => setTimeout(r, 500))
    const final = 85 + Math.floor(Math.random() * 10)
    setAuthenticityScore(final)
    setThreatLevel(final >= 80 ? "Low" : final >= 50 ? "Medium" : "High")
    setRadarData({ bias: 75, accuracy: 88, safety: 82, transparency: 70, privacy: 85 })
    setProcessLogs(prev => {
      const logs = [...prev]
      if (logs.length > 0) logs[logs.length - 1] = { ...logs[logs.length - 1], status: "completed" }
      return logs
    })
    setCertStatus(final >= 80 ? "pass" : "fail")
    setIsAnalyzing(false)
  }, [selectedFile])

  const handleChatSend = () => {
    if (!chatMessage.trim()) return
    setChatMessage("")
  }

  return (
    <div className="flex flex-col h-screen overflow-hidden" style={{ background: "#0B0F19" }}>
      <Header mode={mode} onModeChange={setMode} />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar activeItem={activeNav} onItemSelect={setActiveNav} mode={mode} />

        <main className="flex-1 overflow-hidden flex flex-col">
          <AnimatePresence mode="wait">
            {mode === "deepfake" ? (
              /* ── DETECTION HUB: 3-column layout ── */
              <motion.div
                key="deepfake"
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 16 }}
                transition={{ duration: 0.25 }}
                className="flex-1 overflow-hidden grid"
                style={{ gridTemplateColumns: "220px 1fr 268px", gap: "0" }}
              >
                {/* LEFT: Process Log */}
                <div
                  className="overflow-hidden p-4"
                  style={{ borderRight: "1px solid var(--glass-border)" }}
                >
                  <ProcessLog steps={processLogs} isActive={isAnalyzing} />
                </div>

                {/* CENTER: Detection Hub */}
                <div className="overflow-y-auto p-6 flex flex-col gap-5">
                  <DetectionHub
                    onFileSelect={handleFileSelect}
                    isScanning={isAnalyzing}
                    scanStatus={isAnalyzing ? "SCANNER ACTIVE: ANALYZING SUB-PIXEL ARTIFACTS" : undefined}
                  />

                  {/* Run Audit button */}
                  <motion.button
                    whileHover={{ scale: 1.01, boxShadow: "0 0 32px rgba(0,245,255,0.2)" }}
                    whileTap={{ scale: 0.98 }}
                    onClick={runAudit}
                    disabled={isAnalyzing || !selectedFile}
                    className="w-full py-3.5 rounded-xl text-sm font-bold tracking-widest flex items-center justify-center gap-2 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                    style={{
                      background: "linear-gradient(135deg, rgba(0,245,255,0.15), rgba(0,100,200,0.1))",
                      border: "1px solid rgba(0,245,255,0.4)",
                      color: "var(--cyan)",
                      boxShadow: "inset 0 1px 0 rgba(0,245,255,0.1)"
                    }}
                  >
                    {isAnalyzing ? (
                      <>
                        <div className="w-4 h-4 border-2 rounded-full animate-spin" style={{ borderColor: "rgba(0,245,255,0.3)", borderTopColor: "var(--cyan)" }} />
                        ANALYZING...
                      </>
                    ) : (
                      <>
                        <Rocket size={15} />
                        RUN TECHNICAL AUDIT
                      </>
                    )}
                  </motion.button>
                </div>

                {/* RIGHT: Audit Analytics — NO certificate here */}
                <div
                  className="overflow-y-auto p-4"
                  style={{ borderLeft: "1px solid var(--glass-border)" }}
                >
                  <AuditAnalytics
                    authenticityScore={authenticityScore}
                    threatLevel={threatLevel}
                    isAnalyzing={isAnalyzing}
                    radarData={radarData}
                  />
                </div>
              </motion.div>
            ) : (
              /* ── AI AUDIT: 2-column layout ── */
              <motion.div
                key="ai-audit"
                initial={{ opacity: 0, x: 16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -16 }}
                transition={{ duration: 0.25 }}
                className="flex-1 overflow-y-auto"
              >
                <div className="grid h-full" style={{ gridTemplateColumns: "1fr 300px", gap: "0" }}>
                  {/* LEFT: Model upload + parameters */}
                  <div className="overflow-y-auto p-6">
                    <CompanyWorkspace
                      onFileSelect={handleFileSelect}
                      onRunAudit={runAudit}
                      isAnalyzing={isAnalyzing}
                      selectedFile={selectedFile}
                    />
                  </div>

                  {/* RIGHT: Certificate + Dimension Scores + Diagnostics — ONLY HERE */}
                  <div
                    className="overflow-y-auto p-4 flex flex-col gap-4"
                    style={{ borderLeft: "1px solid var(--glass-border)" }}
                  >
                    <CertificationCard
                      status={certStatus}
                      onReAudit={runAudit}
                      onDownload={() => alert("Downloading certificate...")}
                    />
                    <DimensionScores
                      bias={dimScores.bias}
                      safety={dimScores.safety}
                      performance={dimScores.performance}
                    />
                    <DiagnosticsPanel entries={DIAGNOSTICS} />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Chat bar — always visible at bottom */}
          <div
            className="flex-shrink-0 px-4 py-3 flex items-center gap-3"
            style={{ borderTop: "1px solid var(--glass-border)", background: "rgba(6,9,18,0.85)", backdropFilter: "blur(20px)" }}
          >
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(0,245,255,0.1)", border: "1px solid rgba(0,245,255,0.2)" }}
            >
              <Sparkles size={14} style={{ color: "var(--cyan)" }} />
            </div>
            <input
              type="text"
              value={chatMessage}
              onChange={(e) => setChatMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleChatSend()}
              placeholder={mode === "ai-audit" ? "Ask Sentinel AI about model compliance..." : "Ask Sentinel AI about this detection result..."}
              className="flex-1 text-[13px] outline-none bg-transparent"
              style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: "10px",
                padding: "9px 14px",
                color: "oklch(0.82 0.005 220)",
              }}
            />
            <motion.button
              whileHover={{ scale: 1.04, boxShadow: "0 0 20px rgba(0,245,255,0.25)" }}
              whileTap={{ scale: 0.96 }}
              onClick={handleChatSend}
              className="px-4 py-2.5 rounded-xl text-[12px] font-bold tracking-widest flex items-center gap-2 flex-shrink-0"
              style={{ background: "var(--cyan)", color: "#0B0F19" }}
            >
              <Send size={12} />
              QUERY AI
            </motion.button>
          </div>
        </main>
      </div>
    </div>
  )
}
