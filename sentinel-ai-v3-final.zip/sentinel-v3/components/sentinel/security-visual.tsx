"use client"

import { motion } from "framer-motion"
import { Shield } from "lucide-react"

interface SecurityVisualProps {
  clusterId?: string
  clusterName?: string
}

export function SecurityVisual({ clusterId = "SECURE_DC_04", clusterName = "North Cluster | Tier 4 Safety" }: SecurityVisualProps) {
  return (
    <div className="rounded-xl bg-card/60 backdrop-blur-sm border border-border/50 overflow-hidden">
      {/* Grid Visual */}
      <div className="relative h-32 bg-gradient-to-br from-background to-card overflow-hidden">
        {/* Grid Lines */}
        <svg className="absolute inset-0 w-full h-full opacity-30">
          <defs>
            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-primary/30" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>

        {/* Animated Shield */}
        <motion.div
          className="absolute inset-0 flex items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <div className="relative">
            {/* Outer glow rings */}
            <motion.div
              className="absolute inset-0 rounded-full bg-primary/20 blur-xl"
              animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.6, 0.3] }}
              transition={{ duration: 3, repeat: Infinity }}
              style={{ width: 80, height: 80, marginLeft: -20, marginTop: -20 }}
            />
            <Shield className="w-10 h-10 text-primary" style={{ filter: "drop-shadow(0 0 10px rgba(0, 212, 255, 0.5))" }} />
          </div>
        </motion.div>

        {/* Scanning Lines */}
        <motion.div
          className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent"
          animate={{ top: ["0%", "100%", "0%"] }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        />
      </div>

      {/* Info */}
      <div className="p-3 border-t border-border/50">
        <p className="font-mono text-sm text-foreground">{clusterId}</p>
        <p className="text-xs text-muted-foreground">{clusterName}</p>
      </div>
    </div>
  )
}
