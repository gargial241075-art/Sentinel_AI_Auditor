"use client"

import { motion } from "framer-motion"
import {
  LayoutDashboard, Brain, ScrollText, Settings, Shield,
  ChevronRight
} from "lucide-react"
import { cn } from "@/lib/utils"

interface SidebarProps {
  activeItem: string
  onItemSelect: (item: string) => void
  mode: "deepfake" | "ai-audit"
  userName?: string
}

const NAV_GROUPS = [
  {
    label: "WORKSPACE",
    items: [
      { id: "dashboard", icon: LayoutDashboard, label: "Dashboard" },
      { id: "detection-hub", icon: Brain, label: "Detection Hub" },
    ]
  },
  {
    label: "AUDIT",
    items: [
      { id: "ai-audit", icon: Shield, label: "AI Audit" },
      { id: "logs", icon: ScrollText, label: "Audit Logs" },
    ]
  },
  {
    label: "SYSTEM",
    items: [
      { id: "settings", icon: Settings, label: "Settings" },
    ]
  }
]

export function Sidebar({ activeItem, onItemSelect, mode, userName = "Core Oversight" }: SidebarProps) {
  return (
    <motion.aside
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.4 }}
      className="w-[220px] flex-shrink-0 flex flex-col h-full"
      style={{ background: "rgba(8,12,24,0.7)", borderRight: "1px solid var(--glass-border)", backdropFilter: "blur(20px)" }}
    >
      {/* User identity */}
      <div className="p-4 border-b" style={{ borderColor: "var(--glass-border)" }}>
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold flex-shrink-0"
            style={{
              background: "linear-gradient(135deg, rgba(0,245,255,0.3), rgba(0,100,200,0.2))",
              border: "1px solid rgba(0,245,255,0.4)",
              color: "var(--cyan)",
              fontFamily: "monospace"
            }}
          >
            CO
          </div>
          <div className="min-w-0">
            <div className="text-sm font-semibold truncate" style={{ color: "oklch(0.96 0.005 220)" }}>
              {userName}
            </div>
            <div className="text-[10px] font-mono tracking-widest" style={{ color: "var(--cyan)" }}>
              ENTERPRISE TIER
            </div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-3 overflow-y-auto">
        {NAV_GROUPS.map((group) => (
          <div key={group.label} className="mb-4">
            <div
              className="text-[9px] font-mono tracking-[3px] px-4 py-1.5 mb-1"
              style={{ color: "oklch(0.4 0.02 255)" }}
            >
              {group.label}
            </div>
            {group.items.map(({ id, icon: Icon, label }) => {
              const isActive = activeItem === id
              return (
                <motion.button
                  key={id}
                  whileHover={{ x: 3 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => onItemSelect(id)}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-[13px] font-medium transition-all duration-200 relative group"
                  style={{
                    color: isActive ? "var(--cyan)" : "oklch(0.58 0.02 240)",
                    background: isActive ? "rgba(0,245,255,0.06)" : "transparent",
                    borderLeft: isActive ? "2px solid var(--cyan)" : "2px solid transparent",
                  }}
                >
                  <Icon size={15} className="flex-shrink-0" />
                  <span>{label}</span>
                  {isActive && (
                    <motion.div
                      layoutId="nav-indicator"
                      className="absolute right-3"
                      transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    >
                      <ChevronRight size={12} style={{ color: "var(--cyan)" }} />
                    </motion.div>
                  )}
                </motion.button>
              )
            })}
          </div>
        ))}
      </nav>

      {/* Enterprise badge */}
      <div className="p-3 border-t" style={{ borderColor: "var(--glass-border)" }}>
        <div
          className="rounded-xl p-3"
          style={{ background: "rgba(0,245,255,0.04)", border: "1px solid rgba(0,245,255,0.1)" }}
        >
          <div className="flex items-center gap-2 mb-1">
            <Shield size={13} style={{ color: "var(--cyan)" }} />
            <span className="text-xs font-semibold" style={{ color: "oklch(0.85 0.005 220)" }}>Enterprise Tier</span>
          </div>
          <div className="text-[10px] font-mono" style={{ color: "var(--green)" }}>L3 NEURAL SHIELD ACTIVE</div>
          <div className="text-[9px] font-mono mt-1" style={{ color: "oklch(0.4 0.02 255)" }}>SECURE_DC_04</div>
        </div>
      </div>
    </motion.aside>
  )
}
