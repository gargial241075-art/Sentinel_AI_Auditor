"use client"

import { motion } from "framer-motion"
import { Activity, TrendingUp, Shield } from "lucide-react"
import { RadarChart } from "./radar-chart"

interface AuditAnalyticsProps {
  authenticityScore: number
  threatLevel: "Low" | "Medium" | "High"
  isAnalyzing: boolean
  radarData: {
    bias: number; accuracy: number; safety: number; transparency: number; privacy: number
  }
}

const threatColors: Record<string, string> = {
  Low: "var(--green)",
  Medium: "#ffaa00",
  High: "#ff3366",
}

export function AuditAnalytics({ authenticityScore, threatLevel, isAnalyzing, radarData }: AuditAnalyticsProps) {
  return (
    <div className="flex flex-col gap-3 h-full overflow-y-auto">
      {/* Section header */}
      <SectionHeader Icon={Activity} label="AUDIT ANALYTICS" />

      {/* Authenticity Score — big circular display */}
      <div
        className="rounded-2xl p-5 flex flex-col items-center"
        style={{ background: "rgba(8,12,22,0.6)", backdropFilter: "blur(20px)", border: "1px solid var(--glass-border)" }}
      >
        {/* Conic gradient gauge */}
        <div className="relative w-28 h-28 mb-3">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(0,245,255,0.08)" strokeWidth="8" />
            <motion.circle
              cx="50" cy="50" r="42"
              fill="none"
              stroke="var(--cyan)"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 42}`}
              initial={{ strokeDashoffset: 2 * Math.PI * 42 }}
              animate={{ strokeDashoffset: 2 * Math.PI * 42 * (1 - authenticityScore / 100) }}
              transition={{ duration: 1.2, ease: "easeOut" }}
              style={{ filter: "drop-shadow(0 0 8px rgba(0,245,255,0.6))" }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <motion.span
              key={authenticityScore}
              initial={{ scale: 0.7, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-3xl font-bold text-glow"
              style={{ color: "var(--cyan)", fontFamily: "'Syne', sans-serif" }}
            >
              {authenticityScore}
            </motion.span>
            <span className="text-[9px] font-mono" style={{ color: "oklch(0.45 0.02 255)" }}>%</span>
          </div>
        </div>
        <div className="text-[10px] font-mono tracking-[2px]" style={{ color: "oklch(0.45 0.02 255)" }}>
          AUTHENTICITY SCORE
        </div>

        {/* Threat Level */}
        <div
          className="mt-3 w-full flex items-center justify-between px-3 py-2.5 rounded-xl"
          style={{ background: "rgba(0,0,0,0.3)", border: "1px solid var(--glass-border)" }}
        >
          <div>
            <div className="text-[9px] font-mono tracking-wider" style={{ color: "oklch(0.4 0.02 255)" }}>THREAT LEVEL</div>
            <div className="text-sm font-semibold mt-0.5 flex items-center gap-2" style={{ color: threatColors[threatLevel] }}>
              <motion.div
                className="w-[6px] h-[6px] rounded-full"
                style={{ background: threatColors[threatLevel] }}
                animate={{ opacity: [1, 0.3, 1], scale: [1, 0.6, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
              {threatLevel} Risk
            </div>
          </div>
          <TrendingUp size={18} style={{ color: threatColors[threatLevel] }} />
        </div>
      </div>

      {/* Audit Dimensions Radar */}
      <div
        className="rounded-2xl p-4 flex flex-col items-center"
        style={{ background: "rgba(8,12,22,0.6)", backdropFilter: "blur(20px)", border: "1px solid var(--glass-border)" }}
      >
        <div className="text-[10px] font-mono tracking-[2px] mb-2 self-start" style={{ color: "oklch(0.4 0.02 255)" }}>
          AUDIT DIMENSIONS
        </div>
        <RadarChart data={radarData} isAnimating={isAnalyzing} />

        {/* Score pills */}
        <div className="grid grid-cols-2 gap-1.5 w-full mt-3">
          {[
            { label: "ACCURACY", value: Math.round(radarData.accuracy) },
            { label: "SAFETY", value: Math.round(radarData.safety) },
            { label: "PRIVACY", value: Math.round(radarData.privacy) },
            { label: "BIAS", value: Math.round(radarData.bias) },
            { label: "TRANSP.", value: Math.round(radarData.transparency) },
          ].map(({ label, value }) => (
            <div
              key={label}
              className="rounded-lg p-2 text-center"
              style={{ background: "rgba(0,245,255,0.04)", border: "1px solid rgba(0,245,255,0.08)" }}
            >
              <div className="text-base font-bold" style={{ color: "var(--cyan)", fontFamily: "'Syne', sans-serif" }}>{value}</div>
              <div className="text-[9px] font-mono" style={{ color: "oklch(0.4 0.02 255)" }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Security Tier */}
      <div
        className="rounded-2xl p-4"
        style={{ background: "rgba(8,12,22,0.6)", backdropFilter: "blur(20px)", border: "1px solid var(--glass-border)" }}
      >
        <div className="text-[10px] font-mono tracking-[2px] mb-3" style={{ color: "oklch(0.4 0.02 255)" }}>SECURITY TIER</div>
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: "rgba(0,245,255,0.08)", border: "1px solid rgba(0,245,255,0.2)" }}
          >
            <Shield size={16} style={{ color: "var(--cyan)" }} />
          </div>
          <div>
            <div className="text-sm font-semibold" style={{ color: "oklch(0.85 0.005 220)" }}>Enterprise Tier</div>
            <div className="text-[10px] font-mono" style={{ color: "var(--green)" }}>L3 Neural Shield Active</div>
          </div>
        </div>
      </div>
    </div>
  )
}

function SectionHeader({ Icon, label }: { Icon: any; label: string }) {
  return (
    <div className="flex items-center gap-2 px-1">
      <Icon size={12} style={{ color: "var(--cyan)" }} />
      <span className="text-[10px] font-mono tracking-[2px]" style={{ color: "oklch(0.4 0.02 255)" }}>{label}</span>
    </div>
  )
}
