"use client"

import { useState, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Video, Mic, ImageIcon, FileUp, Upload, X, FolderOpen, CloudDownload } from "lucide-react"
import { cn } from "@/lib/utils"

type TabType = "video" | "audio" | "image" | "file"

const TABS: { id: TabType; label: string; icon: any; accept: string }[] = [
  { id: "video", label: "VIDEO", icon: Video, accept: "video/*" },
  { id: "audio", label: "AUDIO", icon: Mic, accept: "audio/*" },
  { id: "image", label: "IMAGE", icon: ImageIcon, accept: "image/*" },
  { id: "file", label: "TEXT", icon: FileUp, accept: ".pdf,.doc,.docx,.txt,.json,.py,.csv" },
]

interface DetectionHubProps {
  onFileSelect: (file: File | null, type: TabType) => void
  isScanning?: boolean
  scanStatus?: string
}

export function DetectionHub({ onFileSelect, isScanning = false, scanStatus }: DetectionHubProps) {
  const [activeTab, setActiveTab] = useState<TabType>("video")
  const [dragActive, setDragActive] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault(); e.stopPropagation()
    setDragActive(e.type === "dragenter" || e.type === "dragover")
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault(); e.stopPropagation(); setDragActive(false)
    const file = e.dataTransfer.files?.[0]
    if (file) { setSelectedFile(file); onFileSelect(file, activeTab) }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) { setSelectedFile(file); onFileSelect(file, activeTab) }
  }

  const clearSelection = () => {
    setSelectedFile(null); onFileSelect(null, activeTab)
    if (fileInputRef.current) fileInputRef.current.value = ""
  }

  const accept = TABS.find(t => t.id === activeTab)?.accept || "*"

  return (
    <div>
      {/* Title */}
      <div className="mb-5">
        <h1 className="text-2xl font-bold tracking-tight mb-1" style={{ color: "oklch(0.95 0.005 220)", fontFamily: "'Syne', sans-serif" }}>
          Detection Hub
        </h1>
        <p className="text-[11px] font-mono tracking-wider" style={{ color: "oklch(0.45 0.02 255)" }}>
          MULTI-LAYER CRYPTOGRAPHIC + AI DEEPFAKE ANALYSIS · SENTINEL PROTOCOL ACTIVE
        </p>
      </div>

      {/* Media type tabs */}
      <div className="flex gap-2 mb-5">
        {TABS.map(({ id, label, icon: Icon }, i) => {
          const isActive = activeTab === id
          return (
            <motion.button
              key={id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => { setActiveTab(id); clearSelection() }}
              className="flex flex-col items-center gap-2 px-5 py-3.5 rounded-xl min-w-[90px] transition-all duration-200"
              style={{
                background: isActive ? "rgba(0,245,255,0.08)" : "rgba(255,255,255,0.03)",
                border: isActive ? "1px solid rgba(0,245,255,0.4)" : "1px solid rgba(255,255,255,0.06)",
                boxShadow: isActive ? "0 0 20px rgba(0,245,255,0.1), inset 0 1px 0 rgba(0,245,255,0.1)" : "none",
              }}
            >
              <Icon
                size={22}
                style={{
                  color: isActive ? "var(--cyan)" : "oklch(0.45 0.02 255)",
                  filter: isActive ? "drop-shadow(0 0 6px rgba(0,245,255,0.7))" : "none",
                }}
              />
              <span
                className="text-[10px] font-mono tracking-widest"
                style={{ color: isActive ? "var(--cyan)" : "oklch(0.45 0.02 255)" }}
              >
                {label}
              </span>
            </motion.button>
          )
        })}
      </div>

      {/* Drop / Upload Zone */}
      <AnimatePresence mode="wait">
        {selectedFile ? (
          <motion.div
            key="file"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="flex items-center justify-between p-4 rounded-2xl"
            style={{ background: "rgba(0,245,255,0.06)", border: "1px solid rgba(0,245,255,0.2)" }}
          >
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: "rgba(0,245,255,0.1)", border: "1px solid rgba(0,245,255,0.2)" }}
              >
                {(() => { const T = TABS.find(t => t.id === activeTab); return T ? <T.icon size={18} style={{ color: "var(--cyan)" }} /> : null })()}
              </div>
              <div>
                <p className="text-sm font-medium truncate max-w-[200px]" style={{ color: "oklch(0.9 0.005 220)" }}>{selectedFile.name}</p>
                <p className="text-[11px] font-mono" style={{ color: "oklch(0.45 0.02 255)" }}>
                  {(selectedFile.size / 1024 / 1024).toFixed(2)} MB · Ready for analysis
                </p>
              </div>
            </div>
            <button onClick={clearSelection} className="p-2 rounded-lg hover:bg-white/5 transition-colors" style={{ color: "oklch(0.45 0.02 255)" }}>
              <X size={16} />
            </button>
          </motion.div>
        ) : (
          <motion.div
            key="dropzone"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className="rounded-2xl border-2 border-dashed p-10 text-center transition-all duration-300 grid-bg"
            style={{
              background: dragActive ? "rgba(0,245,255,0.05)" : "rgba(255,255,255,0.01)",
              borderColor: dragActive ? "rgba(0,245,255,0.5)" : "rgba(0,245,255,0.12)",
            }}
          >
            <motion.div
              animate={dragActive ? { scale: 1.1, filter: "drop-shadow(0 0 16px rgba(0,245,255,0.8))" } : { scale: 1 }}
              className="flex justify-center mb-4"
            >
              <Upload size={42} style={{ color: dragActive ? "var(--cyan)" : "oklch(0.35 0.02 255)", transition: "all 0.3s" }} />
            </motion.div>
            <p className="text-[15px] font-semibold mb-1" style={{ color: "oklch(0.85 0.005 220)" }}>
              Drop Media for Sentinel Analysis
            </p>
            <p className="text-xs font-mono mb-6" style={{ color: "oklch(0.42 0.02 255)" }}>
              Drag & drop video, audio, image or document file here · Max 4GB
            </p>
            <div className="flex justify-center gap-3">
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", color: "oklch(0.75 0.01 220)" }}
              >
                <FolderOpen size={14} /> Browse Local
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all"
                style={{ background: "rgba(0,245,255,0.08)", border: "1px solid rgba(0,245,255,0.25)", color: "var(--cyan)" }}
              >
                <CloudDownload size={14} /> Import Cloud
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <input ref={fileInputRef} type="file" accept={accept} onChange={handleFileInput} className="hidden" />

      {/* Scanner bar */}
      <AnimatePresence>
        {isScanning && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-4 space-y-2"
          >
            <div className="h-1 rounded-full overflow-hidden" style={{ background: "rgba(0,245,255,0.08)" }}>
              <motion.div
                className="h-full rounded-full"
                style={{ background: "linear-gradient(90deg, var(--cyan), rgba(0,245,255,0.4))", boxShadow: "0 0 12px var(--cyan)" }}
                animate={{ x: ["-100%", "200%"] }}
                transition={{ duration: 1.8, repeat: Infinity, ease: "linear" }}
              />
            </div>
            <p className="text-center text-[11px] font-mono tracking-[2px]" style={{ color: "var(--cyan)" }}>
              {scanStatus || "SCANNER ACTIVE: ANALYZING SUB-PIXEL ARTIFACTS"}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
