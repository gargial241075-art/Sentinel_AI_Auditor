"use client"

import { useState, useRef } from "react"
import { motion } from "framer-motion"
import { Upload, FolderOpen, CloudDownload, Plus, X } from "lucide-react"
import { AuditParameters } from "./audit-parameters"

interface CompanyWorkspaceProps {
  onFileSelect: (file: File | null) => void
  onRunAudit: () => void
  isAnalyzing: boolean
  selectedFile: File | null
}

const defaultBiasParams = [
  { id: "demographic", label: "Demographic Parity", enabled: true },
  { id: "semantic", label: "Semantic Alignment", enabled: true },
  { id: "crossregional", label: "Cross-Regional Sensitivity", enabled: false },
]
const defaultSafetyParams = [
  { id: "pii", label: "PII Leakage Scanning", enabled: true },
  { id: "prompt", label: "Prompt Injection Resistance", enabled: true },
  { id: "adversarial", label: "Adversarial Robustness", enabled: false },
]
const defaultPerformanceParams = [
  { id: "hallucination", label: "Hallucination Threshold", enabled: true },
  { id: "reasoning", label: "Reasoning Consistency", enabled: true },
  { id: "throughput", label: "Throughput Analysis", enabled: false },
]

export function CompanyWorkspace({ onFileSelect, onRunAudit, isAnalyzing, selectedFile }: CompanyWorkspaceProps) {
  const [biasParams, setBiasParams] = useState(defaultBiasParams)
  const [safetyParams, setSafetyParams] = useState(defaultSafetyParams)
  const [performanceParams, setPerformanceParams] = useState(defaultPerformanceParams)
  const [dragActive, setDragActive] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleToggle = (category: string, id: string) => {
    const setter = category === "bias" ? setBiasParams : category === "safety" ? setSafetyParams : setPerformanceParams
    setter(prev => prev.map(p => p.id === id ? { ...p, enabled: !p.enabled } : p))
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) onFileSelect(e.target.files[0])
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault(); setDragActive(false)
    if (e.dataTransfer.files?.[0]) onFileSelect(e.dataTransfer.files[0])
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight mb-1" style={{ color: "oklch(0.95 0.005 220)", fontFamily: "'Syne', sans-serif" }}>
          Model Compliance Workspace
        </h1>
        <p className="text-[11px] font-mono tracking-wider" style={{ color: "oklch(0.45 0.02 255)" }}>
          INITIALIZE SENTINEL PROTOCOL · VERIFY MODEL INTEGRITY AGAINST GLOBAL SAFETY STANDARDS
        </p>
      </div>

      {/* Upload zone */}
      <div
        className="rounded-2xl overflow-hidden"
        style={{ background: "rgba(8,12,22,0.6)", backdropFilter: "blur(20px)", border: "1px solid var(--glass-border)" }}
      >
        <div
          className="p-6 text-center transition-all duration-300"
          style={{ background: dragActive ? "rgba(0,245,255,0.04)" : "transparent" }}
          onDragOver={(e) => { e.preventDefault(); setDragActive(true) }}
          onDragLeave={() => setDragActive(false)}
          onDrop={handleDrop}
        >
          {selectedFile ? (
            <div className="flex items-center justify-between p-4 rounded-xl" style={{ background: "rgba(0,245,255,0.06)", border: "1px solid rgba(0,245,255,0.2)" }}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "rgba(0,245,255,0.1)", border: "1px solid rgba(0,245,255,0.2)" }}>
                  <Upload size={18} style={{ color: "var(--cyan)" }} />
                </div>
                <div className="text-left">
                  <p className="text-sm font-medium" style={{ color: "oklch(0.9 0.005 220)" }}>{selectedFile.name}</p>
                  <p className="text-[11px] font-mono" style={{ color: "oklch(0.45 0.02 255)" }}>{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
              </div>
              <button onClick={() => onFileSelect(null)} className="p-1.5 rounded-lg hover:bg-white/5" style={{ color: "oklch(0.45 0.02 255)" }}>
                <X size={15} />
              </button>
            </div>
          ) : (
            <>
              <div className="flex justify-center mb-4">
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center"
                  style={{ background: "rgba(0,245,255,0.07)", border: "1px solid rgba(0,245,255,0.15)" }}
                >
                  <Upload size={24} style={{ color: dragActive ? "var(--cyan)" : "oklch(0.42 0.02 255)" }} />
                </div>
              </div>
              <p className="text-base font-semibold mb-1" style={{ color: "oklch(0.85 0.005 220)" }}>Data Upload</p>
              <p className="text-[12px] font-mono mb-5" style={{ color: "oklch(0.42 0.02 255)" }}>
                Upload AI Model Code, Dataset Sample, or enter deployment parameters...
              </p>
              <div className="flex justify-center gap-3">
                <motion.button
                  whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                  onClick={() => fileInputRef.current?.click()}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium"
                  style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", color: "oklch(0.75 0.01 220)" }}
                >
                  <FolderOpen size={14} /> Browse Local
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium"
                  style={{ background: "rgba(0,245,255,0.08)", border: "1px solid rgba(0,245,255,0.25)", color: "var(--cyan)" }}
                >
                  <CloudDownload size={14} /> Import Cloud
                </motion.button>
              </div>
            </>
          )}
          <input ref={fileInputRef} type="file" accept=".json,.py,.csv,.txt,.pdf,.doc,.docx,.pt,.pkl" onChange={handleFileInput} className="hidden" />
        </div>
      </div>

      {/* Audit Parameters */}
      <AuditParameters
        biasParams={biasParams}
        safetyParams={safetyParams}
        performanceParams={performanceParams}
        onToggle={handleToggle}
      />

      {/* Run button */}
      <motion.button
        whileHover={{ scale: 1.01, boxShadow: "0 0 24px rgba(0,245,255,0.2)" }}
        whileTap={{ scale: 0.98 }}
        onClick={onRunAudit}
        disabled={isAnalyzing || !selectedFile}
        className="w-full py-3.5 rounded-xl text-sm font-bold tracking-widest flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
        style={{
          background: "transparent",
          border: "2px solid rgba(0,245,255,0.4)",
          color: "var(--cyan)",
        }}
      >
        {isAnalyzing ? (
          <>
            <div className="w-4 h-4 border-2 rounded-full animate-spin" style={{ borderColor: "rgba(0,245,255,0.3)", borderTopColor: "var(--cyan)" }} />
            Running Compliance Audit...
          </>
        ) : (
          <>
            <Plus size={16} />
            NEW AUDIT SCAN
          </>
        )}
      </motion.button>
    </div>
  )
}
