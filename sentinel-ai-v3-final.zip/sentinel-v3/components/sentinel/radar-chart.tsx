"use client"

import { motion } from "framer-motion"

interface RadarChartProps {
  data: {
    bias: number
    accuracy: number
    safety: number
    transparency: number
    privacy: number
  }
  isAnimating?: boolean
}

export function RadarChart({ data, isAnimating = false }: RadarChartProps) {
  const centerX = 100
  const centerY = 100
  const radius = 70
  const labels = ["BIAS", "ACCURACY", "SAFETY", "TRANS.", "PRIVACY"]
  
  // Safely handle undefined data
  const safeData = data || { bias: 20, accuracy: 20, safety: 20, transparency: 20, privacy: 20 }
  const values = [safeData.bias, safeData.accuracy, safeData.safety, safeData.transparency, safeData.privacy]
  const numPoints = 5
  const angleStep = (2 * Math.PI) / numPoints
  const startAngle = -Math.PI / 2 // Start from top

  // Calculate polygon points for data
  const dataPoints = values.map((value, i) => {
    const angle = startAngle + i * angleStep
    const r = (value / 100) * radius
    return {
      x: centerX + r * Math.cos(angle),
      y: centerY + r * Math.sin(angle)
    }
  })

  // Generate grid levels (20%, 40%, 60%, 80%, 100%)
  const gridLevels = [0.2, 0.4, 0.6, 0.8, 1]

  // Calculate label positions
  const labelPositions = labels.map((_, i) => {
    const angle = startAngle + i * angleStep
    const labelRadius = radius + 20
    return {
      x: centerX + labelRadius * Math.cos(angle),
      y: centerY + labelRadius * Math.sin(angle)
    }
  })

  const polygonPath = dataPoints.map((p, i) => 
    `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`
  ).join(' ') + ' Z'

  return (
    <div className="relative w-full aspect-square max-w-[220px] mx-auto">
      <svg viewBox="0 0 200 200" className="w-full h-full">
        {/* Grid Polygons */}
        {gridLevels.map((level, levelIndex) => {
          const gridPoints = Array.from({ length: numPoints }, (_, i) => {
            const angle = startAngle + i * angleStep
            const r = level * radius
            return `${centerX + r * Math.cos(angle)},${centerY + r * Math.sin(angle)}`
          }).join(' ')
          
          return (
            <polygon
              key={levelIndex}
              points={gridPoints}
              fill="none"
              stroke="currentColor"
              strokeWidth="0.5"
              className="text-border/40"
            />
          )
        })}

        {/* Axis Lines */}
        {Array.from({ length: numPoints }, (_, i) => {
          const angle = startAngle + i * angleStep
          return (
            <line
              key={i}
              x1={centerX}
              y1={centerY}
              x2={centerX + radius * Math.cos(angle)}
              y2={centerY + radius * Math.sin(angle)}
              stroke="currentColor"
              strokeWidth="0.5"
              className="text-border/40"
            />
          )
        })}

        {/* Data Polygon */}
        <motion.path
          d={polygonPath}
          fill="rgba(0, 212, 255, 0.15)"
          stroke="rgb(0, 212, 255)"
          strokeWidth="2"
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ 
            opacity: 1, 
            scale: 1,
            d: polygonPath
          }}
          transition={{ 
            duration: isAnimating ? 0.3 : 0.5,
            ease: "easeOut"
          }}
          style={{
            filter: "drop-shadow(0 0 8px rgba(0, 212, 255, 0.4))"
          }}
        />

        {/* Data Points */}
        {dataPoints.map((point, i) => (
          <motion.circle
            key={i}
            cx={point.x}
            cy={point.y}
            r="4"
            fill="rgb(0, 212, 255)"
            initial={{ scale: 0 }}
            animate={{ scale: 1, cx: point.x, cy: point.y }}
            transition={{ delay: i * 0.1, duration: 0.3 }}
            style={{
              filter: "drop-shadow(0 0 4px rgba(0, 212, 255, 0.6))"
            }}
          />
        ))}

        {/* Labels */}
        {labelPositions.map((pos, i) => (
          <text
            key={i}
            x={pos.x}
            y={pos.y}
            textAnchor="middle"
            dominantBaseline="middle"
            className="text-[8px] font-medium fill-muted-foreground uppercase tracking-wider"
          >
            {labels[i]}
          </text>
        ))}
      </svg>
    </div>
  )
}
