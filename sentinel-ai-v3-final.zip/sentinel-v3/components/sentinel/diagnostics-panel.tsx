"use client"

import { motion } from "framer-motion"
import { Activity } from "lucide-react"

interface DiagnosticEntry { type: "SYS" | "SEC" | "AUD" | "NET"; message: string }

const typeColors = { SYS: "var(--cyan)", SEC: "var(--green)", AUD: "#ffaa00", NET: "#a855f7" }

export function DiagnosticsPanel({ entries }: { entries: DiagnosticEntry[] }) {
  return (
    <div
      className="rounded-2xl overflow-hidden"
      style={{ background: "rgba(8,12,22,0.6)", backdropFilter: "blur(20px)", border: "1px solid var(--glass-border)" }}
    >
      <div className="flex items-center gap-2 px-4 py-3" style={{ borderBottom: "1px solid var(--glass-border)" }}>
        <Activity size={13} style={{ color: "var(--cyan)" }} />
        <span className="text-[10px] font-mono tracking-[2px]" style={{ color: "oklch(0.4 0.02 255)" }}>LIVE DIAGNOSTICS</span>
      </div>
      <div className="p-3 space-y-1.5 font-mono text-[11px]">
        {entries.map((entry, i) => (
          <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }} className="flex gap-2">
            <span className="font-bold" style={{ color: typeColors[entry.type] }}>[{entry.type}]</span>
            <span style={{ color: "oklch(0.52 0.02 240)" }}>{entry.message}</span>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
