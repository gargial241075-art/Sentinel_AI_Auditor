"use client"

import { motion } from "framer-motion"
import { Rocket } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Spinner } from "@/components/ui/spinner"
import { cn } from "@/lib/utils"

interface AuditButtonProps {
  onClick: () => void
  isLoading?: boolean
  disabled?: boolean
}

export function AuditButton({ onClick, isLoading, disabled }: AuditButtonProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
    >
      <Button
        onClick={onClick}
        disabled={disabled || isLoading}
        className={cn(
          "w-full h-14 text-base font-semibold rounded-xl",
          "bg-primary hover:bg-primary/90 text-primary-foreground",
          "shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30",
          "transition-all duration-300",
          "disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none"
        )}
      >
        {isLoading ? (
          <div className="flex items-center gap-3">
            <Spinner className="h-5 w-5" />
            <span>Analyzing...</span>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <Rocket className="h-5 w-5" />
            <span>RUN TECHNICAL AUDIT</span>
          </div>
        )}
      </Button>
    </motion.div>
  )
}
