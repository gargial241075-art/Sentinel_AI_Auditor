"use client"

import { motion } from "framer-motion"
import { Brain, Shield, Zap, Sliders } from "lucide-react"

interface AuditParameter { id: string; label: string; enabled: boolean }

interface AuditParametersProps {
  biasParams: AuditParameter[]
  safetyParams: AuditParameter[]
  performanceParams: AuditParameter[]
  onToggle: (category: string, id: string) => void
}

const CATEGORIES = [
  { key: "bias", icon: Brain, label: "BIAS ANALYSIS", color: "var(--cyan)" },
  { key: "safety", icon: Shield, label: "SAFETY & PRIVACY", color: "var(--green)" },
  { key: "performance", icon: Zap, label: "PERFORMANCE & LOGIC", color: "#ffaa00" },
]

export function AuditParameters({ biasParams, safetyParams, performanceParams, onToggle }: AuditParametersProps) {
  const paramMap: Record<string, AuditParameter[]> = {
    bias: biasParams, safety: safetyParams, performance: performanceParams
  }

  return (
    <div
      className="rounded-2xl overflow-hidden"
      style={{ background: "rgba(8,12,22,0.6)", backdropFilter: "blur(20px)", border: "1px solid var(--glass-border)" }}
    >
      <div
        className="flex items-center gap-2 px-5 py-4"
        style={{ borderBottom: "1px solid var(--glass-border)" }}
      >
        <Sliders size={14} style={{ color: "var(--cyan)" }} />
        <span className="text-[12px] font-semibold tracking-wider" style={{ color: "oklch(0.75 0.01 220)" }}>
          AUDIT FOCUS PARAMETERS
        </span>
      </div>
      <div className="p-5 grid grid-cols-3 gap-6">
        {CATEGORIES.map(({ key, icon: Icon, label, color }) => (
          <div key={key}>
            <div className="flex items-center gap-2 mb-3">
              <Icon size={13} style={{ color }} />
              <span className="text-[10px] font-mono tracking-wider font-semibold" style={{ color }}>{label}</span>
            </div>
            <div className="space-y-2.5">
              {paramMap[key].map((param) => (
                <label key={param.id} className="flex items-center gap-2.5 cursor-pointer group">
                  <div
                    className="w-4 h-4 rounded-full border-2 flex items-center justify-center transition-all duration-200 flex-shrink-0"
                    style={{
                      borderColor: param.enabled ? color : "rgba(255,255,255,0.12)",
                      background: param.enabled ? `${color}20` : "transparent",
                    }}
                    onClick={() => onToggle(key, param.id)}
                  >
                    {param.enabled && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-2 h-2 rounded-full"
                        style={{ background: color }}
                      />
                    )}
                  </div>
                  <span
                    className="text-[12px] transition-colors"
                    style={{ color: param.enabled ? "oklch(0.82 0.005 220)" : "oklch(0.45 0.02 255)" }}
                  >
                    {param.label}
                  </span>
                </label>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
