"use client"

import { motion } from "framer-motion"
import { Bell, Lock, User, Scan, Brain } from "lucide-react"
import { cn } from "@/lib/utils"

interface HeaderProps {
  mode: "deepfake" | "ai-audit"
  onModeChange: (mode: "deepfake" | "ai-audit") => void
}

export function Header({ mode, onModeChange }: HeaderProps) {
  return (
    <motion.header
      initial={{ y: -8, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="flex-shrink-0 flex items-center justify-between px-5 h-[54px] z-50"
      style={{
        background: "rgba(6,9,18,0.85)",
        backdropFilter: "blur(24px)",
        borderBottom: "1px solid var(--glass-border)",
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-7">
        <span
          className="text-[18px] font-bold tracking-[3px]"
          style={{
            color: "var(--cyan)",
            textShadow: "0 0 24px rgba(0,245,255,0.5)",
            fontFamily: "'Syne', sans-serif"
          }}
        >
          VAULT<span style={{ color: "oklch(0.45 0.02 255)" }}>_</span>SENTINEL
        </span>

        {/* Mode switcher */}
        <div
          className="flex items-center gap-1 p-1 rounded-xl"
          style={{ background: "rgba(0,245,255,0.04)", border: "1px solid var(--glass-border)" }}
        >
          <ModeTab
            active={mode === "deepfake"}
            onClick={() => onModeChange("deepfake")}
            icon={Scan}
            label="Deepfake Check"
          />
          <ModeTab
            active={mode === "ai-audit"}
            onClick={() => onModeChange("ai-audit")}
            icon={Brain}
            label="AI Audit"
          />
        </div>
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-3">
        {/* Live threat */}
        <div
          className="flex items-center gap-2 px-3 py-1.5 rounded-full text-[11px] font-mono tracking-wider"
          style={{ background: "rgba(255,51,102,0.1)", border: "1px solid rgba(255,51,102,0.25)", color: "#ff3366" }}
        >
          <PulseDot color="#ff3366" fast />
          LIVE THREAT MONITOR
        </div>

        {/* Enterprise */}
        <div
          className="flex items-center gap-2 px-3 py-1.5 rounded-full text-[11px] font-mono tracking-wider"
          style={{ background: "var(--cyan-dim)", border: "1px solid rgba(0,245,255,0.2)", color: "var(--cyan)" }}
        >
          <PulseDot color="var(--cyan)" />
          ENTERPRISE MODE
        </div>

        {/* Icons */}
        <div className="flex items-center gap-1.5 ml-1" style={{ color: "oklch(0.4 0.02 255)" }}>
          <button className="p-2 rounded-lg hover:bg-white/5 transition-colors hover:text-white">
            <Lock size={15} />
          </button>
          <button className="p-2 rounded-lg hover:bg-white/5 transition-colors hover:text-white">
            <Bell size={15} />
          </button>
          <button
            className="w-8 h-8 rounded-full flex items-center justify-center ml-1"
            style={{ background: "rgba(0,245,255,0.1)", border: "1px solid rgba(0,245,255,0.2)" }}
          >
            <User size={14} style={{ color: "var(--cyan)" }} />
          </button>
        </div>
      </div>
    </motion.header>
  )
}

function ModeTab({ active, onClick, icon: Icon, label }: { active: boolean; onClick: () => void; icon: any; label: string }) {
  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-[12px] font-medium transition-all duration-200"
      style={{
        background: active ? "rgba(0,245,255,0.12)" : "transparent",
        color: active ? "var(--cyan)" : "oklch(0.58 0.02 240)",
        border: active ? "1px solid rgba(0,245,255,0.3)" : "1px solid transparent",
        boxShadow: active ? "0 0 16px rgba(0,245,255,0.1)" : "none",
      }}
    >
      <Icon size={13} />
      {label}
    </motion.button>
  )
}

function PulseDot({ color, fast }: { color: string; fast?: boolean }) {
  return (
    <motion.div
      className="w-[6px] h-[6px] rounded-full"
      style={{ background: color }}
      animate={{ opacity: [1, 0.3, 1], scale: [1, 0.6, 1] }}
      transition={{ duration: fast ? 0.7 : 1.5, repeat: Infinity }}
    />
  )
}
