"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Sparkles, Send, Mic } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface ChatInputProps {
  onSend: (message: string) => void
  disabled?: boolean
}

export function ChatInput({ onSend, disabled }: ChatInputProps) {
  const [message, setMessage] = useState("")
  const [isFocused, setIsFocused] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (message.trim()) {
      onSend(message)
      setMessage("")
    }
  }

  return (
    <motion.div 
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-background via-background to-transparent"
    >
      <form 
        onSubmit={handleSubmit}
        className={cn(
          "max-w-3xl mx-auto flex items-center gap-3 p-2 rounded-2xl transition-all duration-200",
          "bg-card/80 border border-border/50 backdrop-blur-xl",
          isFocused && "border-primary/50 shadow-lg shadow-primary/10"
        )}
      >
        <div className="flex items-center gap-2 pl-2">
          <Sparkles className="h-5 w-5 text-primary" />
        </div>
        
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder="Ask Sentinel AI..."
          disabled={disabled}
          className={cn(
            "flex-1 bg-transparent border-none outline-none text-sm",
            "text-foreground placeholder:text-muted-foreground",
            "disabled:opacity-50"
          )}
        />

        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="text-muted-foreground hover:text-foreground"
          >
            <Mic className="h-4 w-4" />
          </Button>
          
          <Button
            type="submit"
            size="icon"
            disabled={!message.trim() || disabled}
            className={cn(
              "rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground",
              "disabled:opacity-50 disabled:cursor-not-allowed"
            )}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </form>
    </motion.div>
  )
}
