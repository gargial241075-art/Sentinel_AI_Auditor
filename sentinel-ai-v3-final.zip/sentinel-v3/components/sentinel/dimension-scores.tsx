"use client"

import { motion } from "framer-motion"
import { BarChart2, Shield, Cpu } from "lucide-react"

interface DimensionScoresProps {
  bias: number
  safety: number
  performance: number
}

const SCORES = [
  { key: "bias" as const, label: "Bias Score", color: "var(--cyan)", icon: BarChart2 },
  { key: "safety" as const, label: "Safety Index", color: "var(--green)", icon: Shield },
  { key: "performance" as const, label: "Performance", color: "#ffaa00", icon: Cpu },
]

export function DimensionScores({ bias, safety, performance }: DimensionScoresProps) {
  const values = { bias, safety, performance }

  return (
    <div
      className="rounded-2xl p-4"
      style={{ background: "rgba(8,12,22,0.6)", backdropFilter: "blur(20px)", border: "1px solid var(--glass-border)" }}
    >
      <div className="text-[10px] font-mono tracking-[2px] mb-4" style={{ color: "oklch(0.4 0.02 255)" }}>
        DIMENSION SCORES
      </div>
      <div className="space-y-4">
        {SCORES.map(({ key, label, color, icon: Icon }) => (
          <div key={key}>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[12px] flex items-center gap-1.5" style={{ color: "oklch(0.65 0.01 240)" }}>
                <Icon size={11} style={{ color }} /> {label}
              </span>
              <span className="text-[12px] font-bold font-mono" style={{ color }}>{values[key]}</span>
            </div>
            <div className="h-2 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.05)" }}>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${values[key]}%` }}
                transition={{ duration: 0.9, ease: "easeOut", delay: 0.2 }}
                className="h-full rounded-full"
                style={{ background: color, boxShadow: `0 0 8px ${color}60` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
