"use client"

import { motion } from "framer-motion"
import { ShieldCheck, ShieldX, Download, RefreshCw } from "lucide-react"

interface CertificationCardProps {
  status: "pass" | "fail" | "pending"
  certificateId?: string
  validationHash?: string
  expiresDate?: string
  onReAudit?: () => void
  onDownload?: () => void
}

export function CertificationCard({
  status,
  certificateId = "SNT-2026-X001",
  validationHash = "f7a9-201c-88e2-0050-sentinel-x-992",
  expiresDate = "AUG 2027",
  onReAudit,
  onDownload
}: CertificationCardProps) {
  const isPassed = status === "pass"
  const isFailed = status === "fail"
  const isPending = status === "pending"

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative rounded-2xl p-5 overflow-hidden"
      style={{
        background: isPassed
          ? "linear-gradient(135deg, rgba(0,245,255,0.07) 0%, rgba(8,12,22,0.7) 100%)"
          : isFailed
          ? "linear-gradient(135deg, rgba(255,51,102,0.07) 0%, rgba(8,12,22,0.7) 100%)"
          : "rgba(8,12,22,0.6)",
        backdropFilter: "blur(20px)",
        border: isPassed
          ? "1px solid rgba(0,245,255,0.3)"
          : isFailed
          ? "1px solid rgba(255,51,102,0.3)"
          : "1px solid var(--glass-border)",
        boxShadow: isPassed ? "0 0 40px rgba(0,245,255,0.08)" : "none"
      }}
    >
      {/* Shimmer top line */}
      {isPassed && (
        <div
          className="absolute top-0 left-0 right-0 h-[1px]"
          style={{ background: "linear-gradient(90deg, transparent, var(--cyan), transparent)" }}
        />
      )}

      {/* Status icon */}
      <div className="flex justify-center mb-3">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
          className="w-14 h-14 rounded-full flex items-center justify-center"
          style={{
            background: isPassed ? "rgba(0,245,255,0.1)" : isFailed ? "rgba(255,51,102,0.1)" : "rgba(255,255,255,0.05)",
            border: isPassed ? "2px solid rgba(0,245,255,0.4)" : isFailed ? "2px solid rgba(255,51,102,0.4)" : "2px solid rgba(255,255,255,0.08)"
          }}
        >
          {isPassed ? (
            <ShieldCheck size={26} style={{ color: "var(--cyan)", filter: "drop-shadow(0 0 8px rgba(0,245,255,0.6))" }} />
          ) : isFailed ? (
            <ShieldX size={26} style={{ color: "#ff3366" }} />
          ) : (
            <div className="w-6 h-6 border-2 rounded-full animate-spin" style={{ borderColor: "rgba(0,245,255,0.3)", borderTopColor: "var(--cyan)" }} />
          )}
        </motion.div>
      </div>

      {/* Status text */}
      <div className="text-center mb-4">
        <div
          className="text-2xl font-bold tracking-[3px]"
          style={{
            color: isPassed ? "var(--green)" : isFailed ? "#ff3366" : "oklch(0.45 0.02 255)",
            fontFamily: "'Syne', sans-serif",
            textShadow: isPassed ? "0 0 20px rgba(0,230,118,0.4)" : "none"
          }}
        >
          {isPassed ? "PASS" : isFailed ? "FAIL" : "PENDING"}
        </div>
        <div className="text-[10px] font-mono tracking-[2px] mt-1" style={{ color: isPassed ? "var(--cyan)" : "oklch(0.4 0.02 255)" }}>
          {isPassed ? "CERTIFIED & SECURE" : isFailed ? "AUDIT FAILED" : "AWAITING ANALYSIS"}
        </div>
      </div>

      {/* Details */}
      {(isPassed || isFailed) && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-0"
        >
          {isPassed && [
            { key: "CERTIFICATE ID", val: certificateId, color: "var(--green)" },
            { key: "VALIDATION HASH", val: validationHash, color: "oklch(0.55 0.02 240)" },
            { key: "EXPIRES", val: expiresDate, color: "#ffaa00" },
          ].map(({ key, val, color }, i, arr) => (
            <div
              key={key}
              className="flex justify-between py-2.5 text-[10px]"
              style={{ borderBottom: i < arr.length - 1 ? "1px solid rgba(0,245,255,0.06)" : "none" }}
            >
              <span className="font-mono" style={{ color: "oklch(0.4 0.02 255)" }}>{key}</span>
              <span className="font-mono text-right" style={{ color, fontSize: "9px", maxWidth: "140px", wordBreak: "break-all" }}>{val}</span>
            </div>
          ))}

          {isFailed && (
            <div className="py-2 border-t" style={{ borderColor: "rgba(255,51,102,0.1)" }}>
              <p className="text-[10px] font-mono mb-2" style={{ color: "oklch(0.4 0.02 255)" }}>FAILED PARAMETERS</p>
              {["Bias Analysis", "PII Leakage"].map(p => (
                <div key={p} className="flex items-center gap-2 text-xs py-0.5" style={{ color: "#ff3366" }}>
                  <span className="w-1.5 h-1.5 rounded-full bg-[#ff3366] flex-shrink-0" />
                  {p}
                </div>
              ))}
            </div>
          )}

          {/* Action button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            onClick={isPassed ? onDownload : onReAudit}
            className="mt-4 w-full py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all"
            style={{
              background: isPassed ? "rgba(0,245,255,0.08)" : "rgba(255,51,102,0.08)",
              border: isPassed ? "1px solid rgba(0,245,255,0.2)" : "1px solid rgba(255,51,102,0.2)",
              color: isPassed ? "var(--cyan)" : "#ff3366"
            }}
          >
            {isPassed ? <Download size={13} /> : <RefreshCw size={13} />}
            {isPassed ? "Download PDF Certificate" : "Request Re-Audit"}
          </motion.button>
        </motion.div>
      )}
    </motion.div>
  )
}
