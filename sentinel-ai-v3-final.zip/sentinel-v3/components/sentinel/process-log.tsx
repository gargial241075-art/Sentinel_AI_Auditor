"use client"

import { motion, AnimatePresence } from "framer-motion"
import { Monitor, AlertTriangle, CheckCircle2, Clock, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"

export interface LogStep {
  id: string
  timestamp: string
  title: string
  description: string
  status: "completed" | "running" | "pending" | "queued" | "alert"
  alertType?: "red" | "amber"
  alertText?: string
}

const statusConfig = {
  completed: { dot: "var(--cyan)", text: "var(--cyan)", icon: CheckCircle2, bg: "rgba(0,245,255,0.05)" },
  running:   { dot: "var(--cyan)", text: "var(--cyan)", icon: Loader2,      bg: "rgba(0,245,255,0.08)" },
  pending:   { dot: "oklch(0.35 0.03 255)", text: "oklch(0.45 0.02 255)", icon: Clock, bg: "rgba(0,0,0,0.2)" },
  queued:    { dot: "oklch(0.28 0.025 255)", text: "oklch(0.38 0.02 255)", icon: Clock, bg: "rgba(0,0,0,0.1)" },
  alert:     { dot: "#ff3366", text: "#ff3366", icon: AlertTriangle, bg: "rgba(255,51,102,0.07)" },
}

export function ProcessLog({ steps, isActive }: { steps: LogStep[]; isActive: boolean }) {
  return (
    <div
      className="h-full flex flex-col rounded-2xl overflow-hidden"
      style={{ background: "rgba(8,12,22,0.6)", backdropFilter: "blur(20px)", border: "1px solid var(--glass-border)" }}
    >
      {/* Header */}
      <div
        className="flex items-center gap-2.5 px-4 py-3.5 flex-shrink-0"
        style={{ borderBottom: "1px solid var(--glass-border)" }}
      >
        <div
          className="w-6 h-6 rounded-lg flex items-center justify-center"
          style={{ background: "rgba(0,245,255,0.1)", border: "1px solid rgba(0,245,255,0.2)" }}
        >
          <Monitor size={13} style={{ color: "var(--cyan)" }} />
        </div>
        <span className="text-[12px] font-semibold tracking-wider" style={{ color: "oklch(0.75 0.01 220)" }}>
          PROCESS LOG
        </span>
        {isActive && (
          <motion.div
            className="ml-auto w-2 h-2 rounded-full"
            style={{ background: "var(--cyan)" }}
            animate={{ opacity: [1, 0.3, 1] }}
            transition={{ duration: 1, repeat: Infinity }}
          />
        )}
      </div>

      {/* Steps */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        <AnimatePresence mode="popLayout">
          {steps.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-12">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center mb-3"
                style={{ background: "rgba(0,245,255,0.05)", border: "1px solid var(--glass-border)" }}
              >
                <Monitor size={20} style={{ color: "oklch(0.35 0.02 255)" }} />
              </div>
              <p className="text-[12px] font-mono" style={{ color: "oklch(0.35 0.02 255)" }}>Awaiting analysis...</p>
              <p className="text-[11px] font-mono mt-1" style={{ color: "oklch(0.28 0.02 255)" }}>Upload media to begin</p>
            </div>
          ) : (
            steps.map((step, i) => {
              const cfg = statusConfig[step.status]
              const Icon = cfg.icon
              return (
                <motion.div
                  key={step.id}
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className="relative rounded-xl p-3 overflow-hidden"
                  style={{
                    background: cfg.bg,
                    border: `1px solid ${step.status === "alert" ? "rgba(255,51,102,0.2)" : step.status === "running" ? "rgba(0,245,255,0.2)" : "rgba(0,245,255,0.06)"}`,
                  }}
                >
                  {/* Timestamp badge */}
                  <div
                    className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-[10px] font-mono mb-2"
                    style={{ background: "rgba(0,0,0,0.3)", color: cfg.text }}
                  >
                    {step.status === "running" ? <Icon size={10} className="animate-spin" /> : <Icon size={10} />}
                    {step.timestamp}
                  </div>
                  <p className="text-[12px] leading-relaxed" style={{ color: "oklch(0.82 0.005 220)" }}>
                    <span className="font-semibold">{step.title}</span>
                    {" "}{step.description}
                    {step.alertText && (
                      <span className="block font-bold mt-0.5" style={{ color: step.alertType === "red" ? "#ff3366" : "#ffaa00" }}>
                        {step.alertText}
                      </span>
                    )}
                  </p>
                  {step.status === "running" && (
                    <motion.div
                      className="absolute bottom-0 left-0 h-[2px] rounded-full"
                      style={{ background: "linear-gradient(90deg, var(--cyan), transparent)" }}
                      initial={{ width: "0%" }}
                      animate={{ width: "100%" }}
                      transition={{ duration: 2.5, repeat: Infinity, ease: "linear" }}
                    />
                  )}
                </motion.div>
              )
            })
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
