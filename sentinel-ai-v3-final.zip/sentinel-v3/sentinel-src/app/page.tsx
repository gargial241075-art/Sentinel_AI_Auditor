"use client"

import { useState, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Rocket, Send, Sparkles } from "lucide-react"
import { Header } from "@/components/sentinel/header"
import { Sidebar } from "@/components/sentinel/sidebar"
import { DetectionHub } from "@/components/sentinel/detection-hub"
import { ProcessLog, LogStep } from "@/components/sentinel/process-log"
import { AuditAnalytics } from "@/components/sentinel/audit-analytics"
import { CertificationCard } from "@/components/sentinel/certification-card"
import { DiagnosticsPanel } from "@/components/sentinel/diagnostics-panel"
import { SecurityVisual } from "@/components/sentinel/security-visual"
import { CompanyWorkspace } from "@/components/sentinel/company-workspace"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

type TabType = "video" | "audio" | "image" | "file"
type Mode = "company" | "consumer"

const initialRadarData = { bias: 20, accuracy: 20, safety: 20, transparency: 20, privacy: 20 }

const scanSteps: Omit<LogStep, "id">[] = [
  { timestamp: "00:42:12", title: "Step 1:", description: "Frame-by-frame neural decomposition initiated...", status: "completed" },
  { timestamp: "00:42:15", title: "Step 2:", description: "Eyeblink rate verified (4 BPM) -", status: "alert", alertType: "red", alertText: "Red Alert: Artifact detected." },
  { timestamp: "00:42:18", title: "Step 3:", description: "Lip-sync phase-shift analysis in progress...", status: "running" },
  { timestamp: "PENDING", title: "Step 4:", description: "Deep spectral audio fingerprinting...", status: "pending" },
  { timestamp: "QUEUED", title: "Step 5:", description: "Metadata authenticity verification...", status: "queued" },
]

const diagnosticEntries = [
  { type: "SYS" as const, message: "Kernel monitoring active..." },
  { type: "SEC" as const, message: "Vault encryption verified." },
  { type: "AUD" as const, message: "Awaiting payload injection." },
]

export default function SentinelAuditor() {
  const [mode, setMode] = useState<Mode>("consumer")
  const [activeNavItem, setActiveNavItem] = useState("dashboard")
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [selectedType, setSelectedType] = useState<TabType>("video")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [authenticityScore, setAuthenticityScore] = useState(0)
  const [threatLevel, setThreatLevel] = useState<"Low" | "Medium" | "High">("Low")
  const [radarData, setRadarData] = useState(initialRadarData)
  const [certificationStatus, setCertificationStatus] = useState<"pass" | "fail" | "pending">("pending")
  const [processLogs, setProcessLogs] = useState<LogStep[]>([])
  const [chatMessage, setChatMessage] = useState("")

  const handleFileSelect = useCallback((file: File | null, type: TabType) => {
    setSelectedFile(file)
    setSelectedType(type)
    setCertificationStatus("pending")
    setProcessLogs([])
    setAuthenticityScore(0)
  }, [])

  const handleCompanyFileSelect = useCallback((file: File | null) => {
    setSelectedFile(file)
    setCertificationStatus("pending")
  }, [])

  const runAudit = useCallback(async () => {
    if (!selectedFile) return
    
    setIsAnalyzing(true)
    setCertificationStatus("pending")
    setProcessLogs([])
    
    // Simulate step-by-step analysis
    for (let i = 0; i < scanSteps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800))
      
      setProcessLogs(prev => {
        const newLogs = [...prev]
        // Update previous step to completed if it was running
        if (newLogs.length > 0 && newLogs[newLogs.length - 1].status === "running") {
          newLogs[newLogs.length - 1] = { ...newLogs[newLogs.length - 1], status: "completed" }
        }
        // Add new step
        const step = scanSteps[i]
        newLogs.push({ ...step, id: `step-${i}`, status: i === scanSteps.length - 1 ? "running" : step.status })
        return newLogs
      })

      // Update metrics progressively
      const progress = (i + 1) / scanSteps.length
      setAuthenticityScore(Math.floor(60 + Math.random() * 35 * progress))
      setRadarData({
        bias: 30 + Math.random() * 60 * progress,
        accuracy: 40 + Math.random() * 55 * progress,
        safety: 35 + Math.random() * 60 * progress,
        transparency: 25 + Math.random() * 70 * progress,
        privacy: 45 + Math.random() * 50 * progress,
      })
    }

    // Final results
    await new Promise(resolve => setTimeout(resolve, 500))
    const finalScore = 85 + Math.floor(Math.random() * 10)
    setAuthenticityScore(finalScore)
    setThreatLevel(finalScore >= 80 ? "Low" : finalScore >= 50 ? "Medium" : "High")
    setRadarData({ bias: 75, accuracy: 88, safety: 82, transparency: 70, privacy: 85 })
    
    // Mark last step as completed
    setProcessLogs(prev => {
      const newLogs = [...prev]
      if (newLogs.length > 0) {
        newLogs[newLogs.length - 1] = { ...newLogs[newLogs.length - 1], status: "completed" }
      }
      return newLogs
    })

    setCertificationStatus(finalScore >= 80 ? "pass" : "fail")
    setIsAnalyzing(false)
  }, [selectedFile])

  const handleChatSend = () => {
    if (!chatMessage.trim()) return
    setChatMessage("")
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header mode={mode} onModeChange={setMode} />
      
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <Sidebar 
          activeItem={activeNavItem} 
          onItemSelect={setActiveNavItem}
          mode={mode}
        />

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          <AnimatePresence mode="wait">
            {mode === "consumer" ? (
              <motion.div
                key="consumer"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="h-full"
              >
                {/* Consumer Mode - 3 Column Layout matching Stitch */}
                <div className="grid grid-cols-1 lg:grid-cols-[200px_1fr_280px] xl:grid-cols-[220px_1fr_300px] gap-4 lg:gap-5 h-full min-h-[600px]">
                  
                  {/* Left Column - Tall Vertical Process Log */}
                  <div className="order-2 lg:order-1 lg:h-full">
                    <ProcessLog steps={processLogs} isActive={isAnalyzing} />
                  </div>

                  {/* Center Column - Detection Hub + Run Button */}
                  <div className="order-1 lg:order-2 flex flex-col gap-4">
                    <DetectionHub
                      onFileSelect={handleFileSelect}
                      isScanning={isAnalyzing}
                      scanStatus={isAnalyzing ? "SCANNER ACTIVE: ANALYZING SUB-PIXEL ARTIFACTS" : undefined}
                    />
                    
                    {/* Run Audit Button */}
                    <motion.div whileHover={{ scale: 1.005 }} whileTap={{ scale: 0.995 }}>
                      <Button
                        onClick={runAudit}
                        disabled={isAnalyzing || !selectedFile}
                        className={cn(
                          "w-full h-12 text-sm font-semibold uppercase tracking-wider rounded-xl",
                          "bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70",
                          "border border-primary/50 shadow-lg shadow-primary/20",
                          "disabled:opacity-50 disabled:cursor-not-allowed"
                        )}
                      >
                        {isAnalyzing ? (
                          <span className="flex items-center gap-2">
                            <span className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                            Analyzing...
                          </span>
                        ) : (
                          <span className="flex items-center gap-2">
                            <Rocket className="w-4 h-4" />
                            Run Technical Audit
                          </span>
                        )}
                      </Button>
                    </motion.div>
                  </div>

                  {/* Right Column - Analytics Panel (Stacked Cards) */}
                  <div className="order-3">
                    <AuditAnalytics
                      authenticityScore={authenticityScore}
                      threatLevel={threatLevel}
                      isAnalyzing={isAnalyzing}
                      radarData={radarData}
                    />
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="company"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                {/* Company Mode - 2 Column Layout */}
                <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-5 max-w-[1400px] mx-auto">
                  {/* Left Column - Workspace */}
                  <div>
                    <CompanyWorkspace
                      onFileSelect={handleCompanyFileSelect}
                      onRunAudit={runAudit}
                      isAnalyzing={isAnalyzing}
                      selectedFile={selectedFile}
                    />
                  </div>

                  {/* Right Column - Certification & Diagnostics (Stacked) */}
                  <div className="space-y-4">
                    <CertificationCard
                      status={certificationStatus}
                      onReAudit={runAudit}
                      onDownload={() => alert("Downloading certificate...")}
                    />
                    <DiagnosticsPanel entries={diagnosticEntries} />
                    <SecurityVisual />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* Fixed Chat Input at Bottom */}
      <div className="sticky bottom-0 border-t border-border/30 bg-background/90 backdrop-blur-md p-4">
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 border border-primary/30">
            <Sparkles className="w-4 h-4 text-primary" />
          </div>
          <div className="flex-1 relative">
            <input
              type="text"
              value={chatMessage}
              onChange={(e) => setChatMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleChatSend()}
              placeholder="Ask Sentinel AI about this detection result..."
              className="w-full h-11 px-4 pr-24 rounded-xl bg-card/50 border border-border/40 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/40"
            />
            <Button
              size="sm"
              onClick={handleChatSend}
              disabled={!chatMessage.trim()}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 h-8 px-4 bg-primary hover:bg-primary/90 rounded-lg text-xs font-semibold uppercase tracking-wide"
            >
              Query AI
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
