"use client"

import { motion } from "framer-motion"
import { Sparkles, ShieldCheck } from "lucide-react"
import { cn } from "@/lib/utils"
import { RadarChart } from "./radar-chart"

interface AuditAnalyticsProps {
  authenticityScore: number
  threatLevel: "Low" | "Medium" | "High"
  isAnalyzing: boolean
  radarData: {
    bias: number
    accuracy: number
    safety: number
    transparency: number
    privacy: number
  }
}

export function AuditAnalytics({ 
  authenticityScore, 
  threatLevel, 
  isAnalyzing,
  radarData 
}: AuditAnalyticsProps) {
  const threatColors = {
    Low: "text-emerald-400",
    Medium: "text-amber-400",
    High: "text-red-400"
  }

  const threatBgColors = {
    Low: "bg-emerald-400",
    Medium: "bg-amber-400",
    High: "bg-red-400"
  }

  const threatGlowColors = {
    Low: "rgba(52, 211, 153, 0.5)",
    Medium: "rgba(251, 191, 36, 0.5)",
    High: "rgba(248, 113, 113, 0.5)"
  }

  return (
    <div className="space-y-4 h-full flex flex-col">
      {/* Header Card with Title */}
      <div className="rounded-2xl bg-card/40 backdrop-blur-sm border border-border/30 p-4">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Audit Analytics</h3>
        </div>

        {/* Authenticity Score - Circular Display */}
        <div className="flex items-center justify-center mb-4">
          <div className="relative w-24 h-24 rounded-full border-[3px] border-primary/30 flex items-center justify-center">
            <motion.div
              className="absolute inset-[3px] rounded-full"
              style={{
                background: `conic-gradient(rgb(0, 212, 255) ${authenticityScore * 3.6}deg, rgba(0, 212, 255, 0.1) 0deg)`
              }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            />
            <div className="relative z-10 bg-card rounded-full w-[70px] h-[70px] flex flex-col items-center justify-center border border-border/30">
              <motion.span 
                className="text-xl font-bold text-foreground"
                key={authenticityScore}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
              >
                {authenticityScore}%
              </motion.span>
              <span className="text-[8px] uppercase tracking-wider text-muted-foreground font-medium">
                Authenticity Score
              </span>
            </div>
          </div>
        </div>

        {/* Threat Level Indicator */}
        <div className="flex items-center justify-between px-3 py-2.5 rounded-xl bg-muted/20 border border-border/20">
          <span className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">Threat Level</span>
          <div className="flex items-center gap-2">
            <span className={cn("text-sm font-semibold", threatColors[threatLevel])}>
              {threatLevel} Risk
            </span>
            <div 
              className={cn("w-2.5 h-2.5 rounded-full", threatBgColors[threatLevel])} 
              style={{ boxShadow: `0 0 8px ${threatGlowColors[threatLevel]}` }} 
            />
          </div>
        </div>
      </div>

      {/* Radar Chart Card - Audit Dimension Scores */}
      <div className="rounded-2xl bg-card/40 backdrop-blur-sm border border-border/30 p-4 flex-1">
        <h4 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-3 text-center">
          Audit Dimension Scores
        </h4>
        <RadarChart data={radarData} isAnimating={isAnalyzing} />
      </div>

      {/* Security Tier Card */}
      <div className="rounded-2xl bg-card/40 backdrop-blur-sm border border-border/30 p-4">
        <h4 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-3">
          Security Tier
        </h4>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/15 flex items-center justify-center border border-emerald-500/30">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">Enterprise Tier</p>
            <p className="text-[11px] text-muted-foreground">L3 Neural Shield Active</p>
          </div>
        </div>
      </div>
    </div>
  )
}
