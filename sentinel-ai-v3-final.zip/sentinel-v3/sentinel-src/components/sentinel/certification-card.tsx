"use client"

import { motion } from "framer-motion"
import { ShieldCheck, ShieldX, Download, RefreshCw } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

interface CertificationCardProps {
  status: "pass" | "fail" | "pending"
  certificateId?: string
  validationHash?: string
  expiresDate?: string
  onReAudit?: () => void
  onDownload?: () => void
}

export function CertificationCard({
  status,
  certificateId = "SNT-2026-X001",
  validationHash = "f7a9-2d1c-88e2-905b- sentinel-x-992",
  expiresDate = "AUG 2027",
  onReAudit,
  onDownload
}: CertificationCardProps) {
  const isPassed = status === "pass"
  const isPending = status === "pending"

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className={cn(
        "rounded-2xl border p-5 backdrop-blur-sm transition-all duration-500",
        isPassed && "border-primary/40 bg-gradient-to-br from-primary/8 via-card/60 to-primary/5",
        status === "fail" && "border-red-500/40 bg-gradient-to-br from-red-500/8 via-card/60 to-red-500/5",
        isPending && "border-border/30 bg-card/40"
      )}
      style={{
        boxShadow: isPassed 
          ? "0 0 40px rgba(0, 212, 255, 0.1), inset 0 1px 0 rgba(255,255,255,0.03)"
          : status === "fail"
          ? "0 0 40px rgba(239, 68, 68, 0.1), inset 0 1px 0 rgba(255,255,255,0.03)"
          : "none"
      }}
    >
      {/* Status Icon */}
      <div className="flex justify-center mb-3">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, delay: 0.15 }}
          className={cn(
            "w-12 h-12 rounded-full flex items-center justify-center",
            isPassed && "bg-primary/15 border border-primary/30",
            status === "fail" && "bg-red-500/15 border border-red-500/30",
            isPending && "bg-muted/40 border border-border/30"
          )}
        >
          {isPassed ? (
            <ShieldCheck className="w-6 h-6 text-primary" />
          ) : status === "fail" ? (
            <ShieldX className="w-6 h-6 text-red-400" />
          ) : (
            <div className="w-5 h-5 border-2 border-muted-foreground border-t-transparent rounded-full animate-spin" />
          )}
        </motion.div>
      </div>

      {/* Status Text */}
      <div className="text-center mb-4">
        <h3 className={cn(
          "text-xl font-bold tracking-wide",
          isPassed && "text-foreground",
          status === "fail" && "text-red-400",
          isPending && "text-muted-foreground"
        )}>
          {isPassed ? "PASS" : status === "fail" ? "NOT CERTIFIED" : "ANALYZING..."}
        </h3>
        <p className={cn(
          "text-[10px] uppercase tracking-[0.15em] mt-1",
          isPassed && "text-primary",
          status === "fail" && "text-red-400/80",
          isPending && "text-muted-foreground"
        )}>
          {isPassed ? "CERTIFIED & SECURE" : status === "fail" ? "AUDIT FAILED" : "PLEASE WAIT"}
        </p>
      </div>

      {/* Certificate Details - Pass State */}
      {isPassed && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="space-y-2.5 text-sm"
        >
          <div className="py-2 border-t border-border/20">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-0.5">Certificate ID</p>
            <p className="font-mono text-sm text-foreground">{certificateId}</p>
          </div>
          <div className="py-2 border-t border-border/20">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-0.5">Validation Hash</p>
            <p className="font-mono text-[11px] text-muted-foreground/80 leading-relaxed">{validationHash}</p>
          </div>
          <div className="py-2 border-t border-border/20">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-0.5">Expires</p>
            <p className="font-semibold text-sm text-primary">{expiresDate}</p>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={onDownload}
            className="w-full mt-3 border-primary/30 text-primary hover:bg-primary/10 rounded-xl h-9 text-xs font-medium"
          >
            <Download className="w-3.5 h-3.5 mr-2" />
            Download PDF Certificate
          </Button>
        </motion.div>
      )}

      {/* Failed State */}
      {status === "fail" && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="space-y-3"
        >
          <div className="py-2 border-t border-border/20">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">Failed Parameters</p>
            <ul className="space-y-1.5">
              {["Bias Analysis", "PII Leakage"].map((param, index) => (
                <li key={index} className="text-sm text-red-400 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                  {param}
                </li>
              ))}
            </ul>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={onReAudit}
            className="w-full mt-2 border-red-500/30 text-red-400 hover:bg-red-500/10 rounded-xl h-9 text-xs font-medium"
          >
            <RefreshCw className="w-3.5 h-3.5 mr-2" />
            Request Re-Audit
          </Button>
        </motion.div>
      )}
    </motion.div>
  )
}
