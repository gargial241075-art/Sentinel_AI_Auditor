"use client"

import { motion } from "framer-motion"
import { 
  LayoutDashboard, 
  FileText, 
  Settings2, 
  Users, 
  Shield,
  ChevronDown,
  Monitor,
  Settings
} from "lucide-react"
import { cn } from "@/lib/utils"

interface SidebarProps {
  activeItem: string
  onItemSelect: (item: string) => void
  mode: "company" | "consumer"
  userName?: string
  userTier?: string
}

const navItems = [
  { id: "dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { id: "logs", icon: FileText, label: "Audit Logs" },
  { id: "api", icon: Settings2, label: "API Management" },
  { id: "users", icon: Users, label: "Multi-User" },
  { id: "vault", icon: Shield, label: "Security Vault" },
]

export function Sidebar({ activeItem, onItemSelect, mode, userName = "Core Oversight", userTier = "ENTERPRISE TIER" }: SidebarProps) {
  return (
    <aside className="w-14 flex-shrink-0 bg-card/30 border-r border-border/30 flex flex-col">
      {/* User Profile - Company Mode Only */}
      {mode === "company" && (
        <div className="p-2.5 border-b border-border/30">
          <div className="w-9 h-9 mx-auto rounded-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center border border-primary/30">
            <span className="text-xs font-bold text-primary">CO</span>
          </div>
        </div>
      )}

      {/* Navigation Items - Icon Only */}
      <nav className="flex-1 py-3">
        <ul className="space-y-1 px-1.5">
          {navItems.map((item) => {
            const isActive = activeItem === item.id
            return (
              <li key={item.id}>
                <button
                  onClick={() => onItemSelect(item.id)}
                  className={cn(
                    "w-full flex items-center justify-center p-2.5 rounded-xl transition-all duration-200",
                    "hover:bg-primary/10",
                    isActive && "bg-primary/15"
                  )}
                  title={item.label}
                >
                  <div className="relative">
                    <item.icon className={cn(
                      "w-5 h-5 transition-colors",
                      isActive ? "text-primary" : "text-muted-foreground"
                    )} />
                    {isActive && (
                      <motion.div
                        layoutId="sidebar-indicator"
                        className="absolute -left-1.5 top-1/2 -translate-y-1/2 w-0.5 h-4 bg-primary rounded-full"
                        transition={{ type: "spring", stiffness: 400, damping: 30 }}
                      />
                    )}
                  </div>
                </button>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Bottom Actions */}
      <div className="p-1.5 border-t border-border/30 space-y-1">
        <button 
          className="w-full flex items-center justify-center p-2.5 rounded-xl text-muted-foreground hover:bg-primary/10 transition-colors"
          title="System Status"
        >
          <Monitor className="w-5 h-5" />
        </button>
        <button 
          className="w-full flex items-center justify-center p-2.5 rounded-xl text-muted-foreground hover:bg-primary/10 transition-colors"
          title="Settings"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>
    </aside>
  )
}
