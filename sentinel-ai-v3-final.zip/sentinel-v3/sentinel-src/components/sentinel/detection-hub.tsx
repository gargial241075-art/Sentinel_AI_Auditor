"use client"

import { useState, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Video, Mic, ImageIcon, FileUp, Upload, X, Settings2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

type TabType = "video" | "audio" | "image" | "file"

const tabs: { id: TabType; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: "video", label: "Video", icon: Video },
  { id: "audio", label: "Audio", icon: Mic },
  { id: "image", label: "Image", icon: ImageIcon },
  { id: "file", label: "File", icon: FileUp },
]

interface DetectionHubProps {
  onFileSelect: (file: File | null, type: TabType) => void
  isScanning?: boolean
  scanStatus?: string
}

export function DetectionHub({ onFileSelect, isScanning = false, scanStatus }: DetectionHubProps) {
  const [activeTab, setActiveTab] = useState<TabType>("video")
  const [dragActive, setDragActive] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0]
      setSelectedFile(file)
      onFileSelect(file, activeTab)
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setSelectedFile(file)
      onFileSelect(file, activeTab)
    }
  }

  const getAcceptedTypes = () => {
    switch (activeTab) {
      case "video": return "video/*"
      case "audio": return "audio/*"
      case "image": return "image/*"
      case "file": return ".pdf,.doc,.docx,.json,.py,.csv,.txt"
      default: return "*"
    }
  }

  const clearSelection = () => {
    setSelectedFile(null)
    onFileSelect(null, activeTab)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  return (
    <div className="rounded-2xl bg-card/40 backdrop-blur-sm border border-border/30 overflow-hidden">
      {/* Header with Title and Settings */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-border/30">
        <h2 className="text-xl font-bold text-foreground tracking-tight">Detection Hub</h2>
        <button className="w-8 h-8 rounded-lg bg-muted/30 flex items-center justify-center hover:bg-muted/50 transition-colors">
          <Settings2 className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      {/* Description */}
      <div className="px-5 py-4 text-center">
        <p className="text-sm text-muted-foreground leading-relaxed max-w-md mx-auto">
          Upload media for comprehensive cryptographic and AI-driven deepfake analysis. Multi-layer verification active.
        </p>
      </div>

      {/* Tabs Row - Horizontal Icons with LED Halos */}
      <div className="flex justify-center gap-3 px-5 pb-5">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id
          const Icon = tab.icon
          
          return (
            <motion.button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id)
                clearSelection()
              }}
              className={cn(
                "relative flex flex-col items-center gap-1.5 p-3 rounded-xl transition-all duration-300",
                "hover:bg-primary/10",
                isActive && "bg-primary/10"
              )}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {/* Icon Container with LED Halo */}
              <div className="relative">
                {isActive && (
                  <motion.div
                    layoutId="detection-tab-halo"
                    className="absolute -inset-1.5 rounded-xl"
                    style={{
                      boxShadow: "0 0 16px rgba(0, 212, 255, 0.5), 0 0 32px rgba(0, 212, 255, 0.25)",
                      background: "radial-gradient(circle, rgba(0, 212, 255, 0.12) 0%, transparent 70%)"
                    }}
                    initial={false}
                    transition={{ type: "spring", stiffness: 400, damping: 35 }}
                  />
                )}
                <div className={cn(
                  "relative w-11 h-11 rounded-xl flex items-center justify-center transition-all duration-300",
                  isActive 
                    ? "bg-primary/25 border-2 border-primary/60" 
                    : "bg-muted/40 border border-border/40"
                )}>
                  <Icon className={cn(
                    "w-5 h-5 transition-colors",
                    isActive ? "text-primary" : "text-muted-foreground"
                  )} />
                </div>
              </div>
              <span className={cn(
                "text-[11px] font-medium transition-colors",
                isActive ? "text-primary" : "text-muted-foreground"
              )}>
                {tab.label}
              </span>
            </motion.button>
          )
        })}
      </div>

      {/* Upload Zone */}
      <div className="px-5 pb-5">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.15 }}
          >
            {selectedFile ? (
              <div className="flex items-center justify-between p-4 rounded-xl bg-primary/10 border border-primary/30">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center border border-primary/30">
                    {(() => {
                      const TabIcon = tabs.find(t => t.id === activeTab)?.icon
                      return TabIcon ? <TabIcon className="w-5 h-5 text-primary" /> : null
                    })()}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground truncate max-w-[180px]">
                      {selectedFile.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={clearSelection}
                  className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ) : (
              <div
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={cn(
                  "relative p-6 rounded-xl border-2 border-dashed transition-all duration-300 cursor-pointer",
                  "flex flex-col items-center justify-center gap-3",
                  dragActive
                    ? "border-primary bg-primary/10 scale-[1.01]"
                    : "border-border/40 bg-muted/15 hover:border-primary/40 hover:bg-muted/25"
                )}
              >
                <motion.div
                  animate={{ scale: dragActive ? 1.1 : 1 }}
                  className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center border border-primary/20"
                >
                  <Upload className={cn(
                    "w-5 h-5 transition-colors",
                    dragActive ? "text-primary" : "text-muted-foreground"
                  )} />
                </motion.div>
                <div className="text-center">
                  <p className="text-sm font-medium text-foreground mb-0.5">
                    Drop media or record
                  </p>
                  <p className="text-xs text-muted-foreground">
                    H.264, ProRes, or RAW files
                  </p>
                </div>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept={getAcceptedTypes()}
              onChange={handleFileInput}
              className="hidden"
            />
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Scanner Status Bar */}
      {isScanning && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="px-5 pb-5"
        >
          <div className="space-y-2.5">
            <div className="h-1.5 rounded-full bg-muted/40 overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-primary via-primary to-primary/60 rounded-full"
                initial={{ width: "0%" }}
                animate={{ width: "100%" }}
                transition={{ duration: 2.5, repeat: Infinity, ease: "linear" }}
              />
            </div>
            <p className="text-[11px] text-primary text-center uppercase tracking-[0.15em] font-semibold">
              {scanStatus || "SCANNER ACTIVE: ANALYZING SUB-PIXEL ARTIFACTS"}
            </p>
          </div>
        </motion.div>
      )}
    </div>
  )
}
