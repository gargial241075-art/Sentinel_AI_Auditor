"use client"

import { Lock, Bell, User } from "lucide-react"
import { cn } from "@/lib/utils"

interface HeaderProps {
  mode: "company" | "consumer"
  onModeChange: (mode: "company" | "consumer") => void
}

export function Header({ mode, onModeChange }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-md">
      <div className="flex items-center justify-between h-14 px-4">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <span className="text-lg font-bold tracking-wider text-primary">VAULT_SENTINEL</span>
          
          {/* Nav Links */}
          <nav className="hidden md:flex items-center gap-1 ml-6">
            <button className={cn(
              "px-3 py-1.5 text-sm font-medium rounded-md transition-colors relative",
              mode === "company" 
                ? "text-primary" 
                : "text-muted-foreground hover:text-foreground"
            )}>
              AI Audit
              {mode === "company" && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary" />
              )}
            </button>
            <button className={cn(
              "px-3 py-1.5 text-sm font-medium rounded-md transition-colors relative",
              mode === "consumer" 
                ? "text-primary" 
                : "text-muted-foreground hover:text-foreground"
            )}>
              Deepfake Check
              {mode === "consumer" && (
                <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary" />
              )}
            </button>
          </nav>
        </div>

        {/* Mode Toggle & Actions */}
        <div className="flex items-center gap-4">
          {/* Operational Mode Toggle */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-card/50 border border-border/50">
            <span className="text-xs text-muted-foreground uppercase tracking-wider">Operational Mode</span>
            <div className="flex items-center gap-0.5 p-0.5 rounded-md bg-muted/50">
              <button
                onClick={() => onModeChange("company")}
                className={cn(
                  "px-2 py-1 text-xs font-medium rounded transition-all duration-200",
                  mode === "company" 
                    ? "bg-primary text-primary-foreground shadow-sm" 
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                COMPANY AI AUDIT
              </button>
              <button
                onClick={() => onModeChange("consumer")}
                className={cn(
                  "px-2 py-1 text-xs font-medium rounded transition-all duration-200",
                  mode === "consumer" 
                    ? "bg-primary text-primary-foreground shadow-sm" 
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                CONSUMER DEEPFAKE CHECK
              </button>
            </div>
          </div>

          {/* Action Icons */}
          <div className="flex items-center gap-2">
            <button className="p-2 rounded-lg hover:bg-muted/50 transition-colors text-muted-foreground hover:text-foreground">
              <Lock className="w-4 h-4" />
            </button>
            <button className="p-2 rounded-lg hover:bg-muted/50 transition-colors text-muted-foreground hover:text-foreground relative">
              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-primary" />
            </button>
            <button className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center border border-primary/20">
              <User className="w-4 h-4 text-primary" />
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
