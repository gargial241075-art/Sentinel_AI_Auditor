"use client"

import { motion } from "framer-motion"
import { Sliders, Brain, Shield, Zap } from "lucide-react"
import { cn } from "@/lib/utils"

interface AuditParameter {
  id: string
  label: string
  enabled: boolean
}

interface AuditParametersProps {
  biasParams: AuditParameter[]
  safetyParams: AuditParameter[]
  performanceParams: AuditParameter[]
  onToggle: (category: string, id: string) => void
}

const categoryConfig = {
  bias: { icon: Brain, label: "BIAS ANALYSIS", color: "text-primary" },
  safety: { icon: Shield, label: "SAFETY & PRIVACY", color: "text-emerald-400" },
  performance: { icon: Zap, label: "PERFORMANCE & LOGIC", color: "text-amber-400" }
}

function ParameterColumn({ 
  category, 
  params, 
  onToggle 
}: { 
  category: "bias" | "safety" | "performance"
  params: AuditParameter[]
  onToggle: (id: string) => void 
}) {
  const config = categoryConfig[category]
  const Icon = config.icon

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Icon className={cn("w-4 h-4", config.color)} />
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          {config.label}
        </h4>
      </div>
      <div className="space-y-2">
        {params.map((param) => (
          <label
            key={param.id}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div
              className={cn(
                "w-4 h-4 rounded-full border-2 transition-all duration-200 flex items-center justify-center",
                param.enabled 
                  ? "border-primary bg-primary/20" 
                  : "border-muted-foreground/30 group-hover:border-muted-foreground/50"
              )}
              onClick={() => onToggle(param.id)}
            >
              {param.enabled && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="w-2 h-2 rounded-full bg-primary"
                />
              )}
            </div>
            <span className={cn(
              "text-sm transition-colors",
              param.enabled ? "text-foreground" : "text-muted-foreground"
            )}>
              {param.label}
            </span>
          </label>
        ))}
      </div>
    </div>
  )
}

export function AuditParameters({ biasParams, safetyParams, performanceParams, onToggle }: AuditParametersProps) {
  return (
    <div className="rounded-xl bg-card/60 backdrop-blur-sm border border-border/50 overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-border/50">
        <Sliders className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">Audit Focus Parameters</h3>
      </div>

      {/* Parameters Grid */}
      <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-6">
        <ParameterColumn
          category="bias"
          params={biasParams}
          onToggle={(id) => onToggle("bias", id)}
        />
        <ParameterColumn
          category="safety"
          params={safetyParams}
          onToggle={(id) => onToggle("safety", id)}
        />
        <ParameterColumn
          category="performance"
          params={performanceParams}
          onToggle={(id) => onToggle("performance", id)}
        />
      </div>
    </div>
  )
}
