"use client"

import { motion } from "framer-motion"
import { Activity } from "lucide-react"

interface DiagnosticEntry {
  type: "SYS" | "SEC" | "AUD" | "NET"
  message: string
}

interface DiagnosticsPanelProps {
  entries: DiagnosticEntry[]
}

const typeColors = {
  SYS: "text-primary",
  SEC: "text-emerald-400",
  AUD: "text-amber-400",
  NET: "text-purple-400"
}

export function DiagnosticsPanel({ entries }: DiagnosticsPanelProps) {
  return (
    <div className="rounded-xl bg-card/60 backdrop-blur-sm border border-border/50 overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-border/50">
        <Activity className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider">Live Diagnostics</h3>
      </div>

      {/* Entries */}
      <div className="p-3 space-y-1.5 font-mono text-xs">
        {entries.map((entry, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-start gap-2"
          >
            <span className={`font-bold ${typeColors[entry.type]}`}>[{entry.type}]</span>
            <span className="text-muted-foreground">{entry.message}</span>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
