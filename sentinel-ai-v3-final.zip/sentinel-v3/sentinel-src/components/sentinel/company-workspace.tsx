"use client"

import { useState, useRef } from "react"
import { motion } from "framer-motion"
import { Upload, Cloud, FolderUp, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { AuditParameters } from "./audit-parameters"

interface CompanyWorkspaceProps {
  onFileSelect: (file: File | null) => void
  onRunAudit: () => void
  isAnalyzing: boolean
  selectedFile: File | null
}

const defaultBiasParams = [
  { id: "demographic", label: "Demographic Parity", enabled: true },
  { id: "semantic", label: "Semantic Alignment", enabled: true },
  { id: "crossregional", label: "Cross-Regional Sensitivity", enabled: false },
]

const defaultSafetyParams = [
  { id: "pii", label: "PII Leakage Scanning", enabled: true },
  { id: "prompt", label: "Prompt Injection Resistance", enabled: true },
  { id: "adversarial", label: "Adversarial Robustness", enabled: false },
]

const defaultPerformanceParams = [
  { id: "hallucination", label: "Hallucination Threshold", enabled: true },
  { id: "reasoning", label: "Reasoning Consistency", enabled: true },
  { id: "throughput", label: "Throughput Analysis", enabled: false },
]

export function CompanyWorkspace({ onFileSelect, onRunAudit, isAnalyzing, selectedFile }: CompanyWorkspaceProps) {
  const [biasParams, setBiasParams] = useState(defaultBiasParams)
  const [safetyParams, setSafetyParams] = useState(defaultSafetyParams)
  const [performanceParams, setPerformanceParams] = useState(defaultPerformanceParams)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleToggle = (category: string, id: string) => {
    if (category === "bias") {
      setBiasParams(prev => prev.map(p => p.id === id ? { ...p, enabled: !p.enabled } : p))
    } else if (category === "safety") {
      setSafetyParams(prev => prev.map(p => p.id === id ? { ...p, enabled: !p.enabled } : p))
    } else if (category === "performance") {
      setPerformanceParams(prev => prev.map(p => p.id === id ? { ...p, enabled: !p.enabled } : p))
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileSelect(e.target.files[0])
    }
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground mb-1.5 tracking-tight">
          Model Compliance Workspace
        </h1>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Initialize the Sentinel Protocol to verify model integrity against global safety standards.
        </p>
      </div>

      {/* Data Upload Card - Matching Stitch Design */}
      <div className="rounded-2xl bg-card/40 backdrop-blur-sm border border-border/30 overflow-hidden">
        <div className="p-6">
          {/* Upload Icon */}
          <div className="flex justify-center mb-4">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center border border-primary/20">
              <Upload className="w-6 h-6 text-primary" />
            </div>
          </div>

          <h2 className="text-lg font-semibold text-foreground text-center mb-1.5">
            Data Upload
          </h2>
          
          <p className="text-sm text-muted-foreground text-center mb-5 max-w-sm mx-auto leading-relaxed">
            Upload AI Model Code, Dataset Sample, or enter deployment parameters...
          </p>

          {/* File Selection Display */}
          {selectedFile && (
            <div className="flex items-center justify-center gap-3 p-3 rounded-xl bg-primary/10 border border-primary/30 mb-5">
              <FolderUp className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-foreground">{selectedFile.name}</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onFileSelect(null)}
                className="ml-auto text-xs text-muted-foreground hover:text-destructive h-7 px-2"
              >
                Remove
              </Button>
            </div>
          )}

          {/* Action Buttons - Side by Side */}
          <div className="flex justify-center gap-3">
            <Button
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              className="border-border/40 hover:bg-muted/30 hover:border-primary/40 rounded-xl h-10 px-5 text-sm"
            >
              <FolderUp className="w-4 h-4 mr-2" />
              Browse Local
            </Button>
            <Button
              variant="outline"
              className="border-border/40 hover:bg-muted/30 hover:border-primary/40 rounded-xl h-10 px-5 text-sm"
            >
              <Cloud className="w-4 h-4 mr-2" />
              Import Cloud
            </Button>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json,.py,.csv,.txt,.pdf,.doc,.docx"
            onChange={handleFileInput}
            className="hidden"
          />
        </div>
      </div>

      {/* Audit Parameters Section */}
      <AuditParameters
        biasParams={biasParams}
        safetyParams={safetyParams}
        performanceParams={performanceParams}
        onToggle={handleToggle}
      />

      {/* + New Audit Scan Button - Matching Stitch Design */}
      <motion.div
        whileHover={{ scale: 1.005 }}
        whileTap={{ scale: 0.995 }}
      >
        <Button
          onClick={onRunAudit}
          disabled={isAnalyzing || !selectedFile}
          variant="outline"
          className={cn(
            "w-full h-12 text-sm font-semibold rounded-xl",
            "border-2 border-primary/60 text-primary",
            "bg-transparent hover:bg-primary/10",
            "disabled:opacity-50 disabled:cursor-not-allowed",
            "transition-all duration-200"
          )}
        >
          {isAnalyzing ? (
            <span className="flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              Running Compliance Audit...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              New Audit Scan
            </span>
          )}
        </Button>
      </motion.div>
    </div>
  )
}
