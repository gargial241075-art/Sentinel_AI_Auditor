"use client"

import { motion, AnimatePresence } from "framer-motion"
import { Monitor, AlertTriangle, CheckCircle2, Clock, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"

export interface LogStep {
  id: string
  timestamp: string
  title: string
  description: string
  status: "completed" | "running" | "pending" | "queued" | "alert"
  alertType?: "red" | "amber"
  alertText?: string
}

interface ProcessLogProps {
  steps: LogStep[]
  isActive: boolean
}

const statusConfig = {
  completed: {
    color: "bg-primary",
    textColor: "text-primary",
    icon: CheckCircle2,
  },
  running: {
    color: "bg-primary",
    textColor: "text-primary",
    icon: Loader2,
  },
  pending: {
    color: "bg-muted",
    textColor: "text-muted-foreground",
    icon: Clock,
  },
  queued: {
    color: "bg-muted/50",
    textColor: "text-muted-foreground/70",
    icon: Clock,
  },
  alert: {
    color: "bg-red-500",
    textColor: "text-red-400",
    icon: AlertTriangle,
  }
}

export function ProcessLog({ steps, isActive }: ProcessLogProps) {
  return (
    <div className="h-full rounded-2xl bg-card/40 backdrop-blur-sm border border-border/30 overflow-hidden flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-2.5 px-4 py-4 border-b border-border/30">
        <div className="w-5 h-5 rounded flex items-center justify-center bg-primary/20">
          <Monitor className="w-3.5 h-3.5 text-primary" />
        </div>
        <h3 className="text-sm font-semibold text-foreground tracking-wide">Process Log</h3>
        {isActive && (
          <span className="ml-auto flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          </span>
        )}
      </div>

      {/* Log Steps - Vertical Stack */}
      <div className="flex-1 p-3 space-y-3 overflow-y-auto">
        <AnimatePresence mode="popLayout">
          {steps.map((step, index) => {
            const config = statusConfig[step.status]
            const Icon = config.icon
            
            return (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ delay: index * 0.05 }}
                className={cn(
                  "relative rounded-xl p-3.5 border transition-all duration-300",
                  step.status === "running" && "border-primary/40 bg-primary/5",
                  step.status === "completed" && "border-primary/30 bg-primary/5",
                  step.status === "alert" && "border-red-500/40 bg-red-500/5",
                  (step.status === "pending" || step.status === "queued") && "border-border/20 bg-card/30 opacity-60"
                )}
              >
                {/* Timestamp Badge with Icon */}
                <div className={cn(
                  "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-mono font-medium mb-2.5",
                  step.status === "running" && "bg-primary/20 text-primary",
                  step.status === "completed" && "bg-primary/15 text-primary",
                  step.status === "alert" && "bg-red-500/20 text-red-400",
                  (step.status === "pending" || step.status === "queued") && "bg-muted/40 text-muted-foreground"
                )}>
                  {step.status === "running" ? (
                    <Icon className="w-3 h-3 animate-spin" />
                  ) : (
                    <Icon className="w-3 h-3" />
                  )}
                  <span>{step.timestamp}</span>
                </div>

                {/* Step Content */}
                <p className="text-[13px] leading-relaxed text-foreground/90">
                  <span className="font-semibold">{step.title}</span>
                  {step.description && (
                    <span className="text-muted-foreground ml-1">{step.description}</span>
                  )}
                  {step.alertText && (
                    <>
                      <br />
                      <span className={cn(
                        "font-semibold",
                        step.alertType === "red" ? "text-red-400" : "text-amber-400"
                      )}>
                        {step.alertText}
                      </span>
                    </>
                  )}
                </p>

                {/* Animated Progress Line for Running Status */}
                {step.status === "running" && (
                  <motion.div
                    className="absolute bottom-0 left-0 h-[2px] bg-gradient-to-r from-primary via-primary to-transparent rounded-full"
                    initial={{ width: "0%" }}
                    animate={{ width: "100%" }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: "linear" }}
                  />
                )}
              </motion.div>
            )
          })}
        </AnimatePresence>

        {steps.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full py-12 text-center">
            <div className="w-12 h-12 rounded-xl bg-muted/30 flex items-center justify-center mb-3">
              <Monitor className="w-5 h-5 text-muted-foreground/50" />
            </div>
            <p className="text-sm text-muted-foreground">Awaiting analysis...</p>
            <p className="text-xs text-muted-foreground/60 mt-1">Upload media to begin</p>
          </div>
        )}
      </div>
    </div>
  )
}
