"""
utils/file_handler.py
──────────────────────────────────────────────────────────────────────────────
Handles file validation, safe storage, and cleanup for uploaded media.
Swap the save path or add cloud storage (S3/GCS) here later.
"""
import os
import uuid
import shutil
import mimetypes
import logging
from pathlib import Path
from fastapi import UploadFile, HTTPException

from core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

# ── Allowed MIME types per media category ─────────────────────────────────────
ALLOWED_TYPES: dict[str, set[str]] = {
    "video": {"video/mp4", "video/avi", "video/quicktime", "video/webm",
              "video/x-matroska", "video/x-msvideo"},
    "audio": {"audio/mpeg", "audio/wav", "audio/ogg", "audio/flac",
              "audio/aac", "audio/x-wav"},
    "image": {"image/jpeg", "image/png", "image/webp", "image/gif",
              "image/bmp", "image/tiff"},
    "text":  {"text/plain", "application/pdf",
              "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
              "application/msword", "application/json",
              "text/csv", "text/x-python"},
}

ALL_ALLOWED: set[str] = {m for mimes in ALLOWED_TYPES.values() for m in mimes}


def _ensure_temp_dir() -> Path:
    path = Path(settings.TEMP_DIR)
    path.mkdir(parents=True, exist_ok=True)
    return path


def detect_media_category(content_type: str, filename: str) -> str:
    """Guess the media category from MIME type, falling back to extension."""
    for category, mimes in ALLOWED_TYPES.items():
        if content_type in mimes:
            return category
    # fallback: guess from extension
    ext = Path(filename).suffix.lower()
    ext_map = {
        ".mp4": "video", ".avi": "video", ".mov": "video", ".mkv": "video",
        ".mp3": "audio", ".wav": "audio", ".ogg": "audio", ".flac": "audio",
        ".jpg": "image", ".jpeg": "image", ".png": "image", ".webp": "image",
        ".txt": "text",  ".pdf": "text",  ".csv": "text",  ".py": "text",
        ".json": "text", ".docx": "text",
    }
    return ext_map.get(ext, "text")


async def save_upload(file: UploadFile) -> tuple[Path, str]:
    """
    Validate and persist an uploaded file.

    Returns
    -------
    (saved_path, media_category)

    Raises
    ------
    HTTPException 400 — bad MIME / too large
    """
    # ── Size pre-check (Content-Length header, if present) ─────────────────
    max_bytes = settings.MAX_UPLOAD_MB * 1024 * 1024

    content_type = file.content_type or mimetypes.guess_type(file.filename or "")[0] or ""
    if content_type not in ALL_ALLOWED:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported media type '{content_type}'. "
                   f"Allowed: {sorted(ALL_ALLOWED)}",
        )

    temp_dir = _ensure_temp_dir()
    job_id = str(uuid.uuid4())
    suffix = Path(file.filename or "upload").suffix or ".bin"
    dest = temp_dir / f"{job_id}{suffix}"

    # ── Stream to disk with size enforcement ───────────────────────────────
    total = 0
    chunk_size = 1024 * 256  # 256 KB
    try:
        with dest.open("wb") as f:
            while chunk := await file.read(chunk_size):
                total += len(chunk)
                if total > max_bytes:
                    dest.unlink(missing_ok=True)
                    raise HTTPException(
                        status_code=413,
                        detail=f"File exceeds maximum size of {settings.MAX_UPLOAD_MB} MB.",
                    )
                f.write(chunk)
    except HTTPException:
        raise
    except Exception as exc:
        dest.unlink(missing_ok=True)
        logger.exception("Error saving upload")
        raise HTTPException(status_code=500, detail=str(exc))

    media_category = detect_media_category(content_type, file.filename or "")
    logger.info(f"Saved upload → {dest} ({total/1024:.1f} KB, category={media_category})")
    return dest, media_category


def cleanup(path: Path) -> None:
    """Remove a temporary file; silently ignore errors."""
    try:
        path.unlink(missing_ok=True)
    except Exception:
        pass
