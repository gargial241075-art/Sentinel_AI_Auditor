"""
utils/hashing.py
──────────────────────────────────────────────────────────────────────────────
Deterministic, tamper-evident certificate hashing.
Uses HMAC-SHA256 so certificates can be verified server-side.
"""
import hmac
import hashlib
import json
from datetime import datetime

from core.config import get_settings

settings = get_settings()


def _canonical(data: dict) -> bytes:
    """Produce a stable, sorted JSON bytes representation."""
    return json.dumps(data, sort_keys=True, default=str).encode()


def sign_certificate(payload: dict) -> str:
    """
    Return HMAC-SHA256 hex digest of *payload* using the server's secret key.
    The digest can be stored alongside the certificate and verified later.
    """
    key = settings.CERT_SECRET_KEY.encode()
    msg = _canonical(payload)
    return hmac.new(key, msg, hashlib.sha256).hexdigest()


def generate_validation_hash(job_id: str, score: float, issued_at: datetime) -> str:
    """
    Short display hash shown on the UI certificate card  (first 32 hex chars).
    Format mirrors the reference design: f7a9-201c-88e2-…
    """
    raw = f"{job_id}:{score:.4f}:{issued_at.isoformat()}"
    full = hashlib.sha256(raw.encode()).hexdigest()
    # Insert dashes every 4 chars for readability
    parts = [full[i:i+4] for i in range(0, 32, 4)]
    return "-".join(parts)


def generate_certificate_id(job_id: str) -> str:
    """E.g.  SNT-2026-A3F1"""
    short = hashlib.sha1(job_id.encode()).hexdigest()[:4].upper()
    year = datetime.utcnow().year
    return f"SNT-{year}-{short}"
