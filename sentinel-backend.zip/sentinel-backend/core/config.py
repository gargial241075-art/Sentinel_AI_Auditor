"""
core/config.py — Centralised settings via pydantic-settings.
Override anything with a .env file or environment variables.
"""
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # ── App ───────────────────────────────────────────────
    APP_NAME: str = "Vault Sentinel API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True

    # ── CORS ──────────────────────────────────────────────
    ALLOWED_ORIGINS: list[str] = [
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ]

    # ── File limits ───────────────────────────────────────
    MAX_UPLOAD_MB: int = 500                         # hard cap per upload
    TEMP_DIR: str = "/tmp/sentinel_uploads"          # ephemeral storage

    # ── Certificate ───────────────────────────────────────
    CERT_VALIDITY_MONTHS: int = 14                   # AUG 2027 from now
    CERT_SECRET_KEY: str = "change-me-in-production" # HMAC signing key

    # ── WebSocket ─────────────────────────────────────────
    WS_PING_INTERVAL: float = 20.0

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache
def get_settings() -> Settings:
    return Settings()
