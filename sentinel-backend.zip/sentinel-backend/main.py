"""
main.py
──────────────────────────────────────────────────────────────────────────────
Vault Sentinel — FastAPI Backend
Run:  uvicorn main:app --reload --port 8000
Docs: http://localhost:8000/docs
"""
import os
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from core.config import get_settings
from core.logging import setup_logging
from routers import detect_router, audit_router, logs_router, report_router

# ── Bootstrap ─────────────────────────────────────────────────────────────────

settings = get_settings()
setup_logging(debug=settings.DEBUG)
logger = logging.getLogger(__name__)


# ── Lifespan (startup / shutdown) ─────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    temp_dir = Path(settings.TEMP_DIR)
    temp_dir.mkdir(parents=True, exist_ok=True)
    logger.info(f"🛡  {settings.APP_NAME} v{settings.APP_VERSION} — startup complete")
    logger.info(f"📂 Temp upload directory: {temp_dir}")
    logger.info(f"🌐 CORS origins: {settings.ALLOWED_ORIGINS}")
    yield
    # Shutdown — clean up any leftover temp files
    import shutil
    if temp_dir.exists():
        shutil.rmtree(temp_dir, ignore_errors=True)
    logger.info("🔒 Sentinel backend shutdown.")


# ── Application factory ───────────────────────────────────────────────────────

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=(
        "Production-ready backend for Vault Sentinel — AI Deepfake Detection "
        "and Model Compliance Auditing.\n\n"
        "**WebSocket** → `ws://localhost:8000/logs/stream`\n\n"
        "Connect your Next.js frontend at `http://localhost:3000`."
    ),
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
)


# ── CORS ──────────────────────────────────────────────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Global exception handler ──────────────────────────────────────────────────

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.exception(f"Unhandled exception on {request.url}")
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "detail": str(exc), "code": 500},
    )


# ── Routers ───────────────────────────────────────────────────────────────────

app.include_router(detect_router)
app.include_router(audit_router)
app.include_router(logs_router)
app.include_router(report_router)


# ── Health & root endpoints ───────────────────────────────────────────────────

@app.get("/", tags=["Health"], summary="Root — redirect hint")
async def root():
    return {
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "online",
        "docs": "/docs",
    }


@app.get("/health", tags=["Health"], summary="Liveness probe")
async def health():
    return {"status": "healthy", "version": settings.APP_VERSION}


# ── Dev runner ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
