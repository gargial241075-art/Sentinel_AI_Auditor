"""
routers/logs.py
──────────────────────────────────────────────────────────────────────────────
WebSocket  /logs/stream

Clients connect with:
  ws://localhost:8000/logs/stream?job_type=media&media_type=video

The server:
  1. Sends a "connected" handshake message
  2. Streams simulated processing log entries (WSLogEntry JSON)
  3. Sends a "complete" message at 100 % progress
  4. Closes the connection

Frontend integration
────────────────────
  const ws = new WebSocket(
    `ws://localhost:8000/logs/stream?job_type=media&media_type=video`
  );
  ws.onmessage = (e) => {
    const entry = JSON.parse(e.data);
    // entry.type: "log" | "complete" | "error"
    // entry.message, entry.progress, entry.tag, entry.status …
  };
"""
import json
import logging
from typing import Literal, Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query

from models.schemas import WSLogEntry
from services.media_analyzer import stream_analysis_logs
from services.model_auditor import stream_audit_logs

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Logs"])


# ─── helper ───────────────────────────────────────────────────────────────────

def _send_factory(ws: WebSocket):
    """Returns a synchronous callback that queues a JSON send."""
    import asyncio

    loop = asyncio.get_event_loop()

    def _send(entry: WSLogEntry) -> None:
        # Schedule the coroutine on the running event loop
        asyncio.ensure_future(ws.send_text(entry.model_dump_json()), loop=loop)

    return _send


# ─── endpoint ─────────────────────────────────────────────────────────────────

@router.websocket("/logs/stream")
async def stream_logs(
    websocket: WebSocket,
    job_type: Literal["media", "model"] = Query(
        "media",
        description="Type of job to simulate: 'media' or 'model'",
    ),
    media_type: Optional[str] = Query(
        "video",
        description="For job_type=media: video | audio | image | text",
    ),
):
    """
    Real-time WebSocket log stream.

    Emits WSLogEntry JSON objects as the analysis 'progresses'.
    Each message has the shape:

    ```json
    {
      "type": "log",
      "step": 3,
      "total_steps": 8,
      "progress": 37.5,
      "tag": "ML",
      "message": "Eyeblink rate verification in progress...",
      "status": "running",
      "timestamp": "2026-05-08T09:34:21.000Z"
    }
    ```
    """
    await websocket.accept()
    logger.info(f"[WS] Client connected — job_type={job_type} media_type={media_type}")

    # Handshake
    handshake = WSLogEntry(
        type="log",
        tag="SYS",
        message="Sentinel WebSocket stream established. Awaiting analysis trigger.",
        status="running",
        progress=0.0,
    )
    await websocket.send_text(handshake.model_dump_json())

    send_cb = _send_factory(websocket)

    try:
        if job_type == "model":
            await stream_audit_logs(callback=send_cb)
        else:
            await stream_analysis_logs(
                media_type=media_type or "video",
                callback=send_cb,
            )
    except WebSocketDisconnect:
        logger.info("[WS] Client disconnected early")
    except Exception as exc:
        logger.exception("[WS] Stream error")
        err = WSLogEntry(
            type="error",
            tag="SYS",
            message=f"Stream error: {exc}",
            status="alert",
            alert_type="red",
        )
        try:
            await websocket.send_text(err.model_dump_json())
        except Exception:
            pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass
        logger.info("[WS] Connection closed")
