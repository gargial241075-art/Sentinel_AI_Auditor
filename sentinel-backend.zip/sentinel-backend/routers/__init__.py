from .detect import router as detect_router
from .audit  import router as audit_router
from .logs   import router as logs_router
from .report import router as report_router

__all__ = ["detect_router", "audit_router", "logs_router", "report_router"]
