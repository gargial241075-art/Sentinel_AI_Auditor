"""
routers/detect.py
──────────────────────────────────────────────────────────────────────────────
POST /detect/media
  Accepts a multipart file upload, runs the media analyser, and returns a
  structured MediaDetectionResponse.

Query params
────────────
  media_type : optional hint ("video"|"audio"|"image"|"text").
               If omitted, detected from MIME type / extension.
"""
import logging
from typing import Optional

from fastapi import APIRouter, File, UploadFile, Query, HTTPException
from fastapi.responses import JSONResponse

from models.schemas import MediaDetectionResponse, ErrorResponse
from services.media_analyzer import analyze_media
from utils.file_handler import save_upload, cleanup

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/detect", tags=["Detection"])


@router.post(
    "/media",
    response_model=MediaDetectionResponse,
    summary="Upload and analyse a media file for deepfake artefacts",
    responses={
        400: {"model": ErrorResponse, "description": "Bad request / unsupported file"},
        413: {"model": ErrorResponse, "description": "File too large"},
        415: {"model": ErrorResponse, "description": "Unsupported media type"},
        500: {"model": ErrorResponse, "description": "Internal analysis error"},
    },
)
async def detect_media(
    file: UploadFile = File(..., description="Video, audio, image, or text file to analyse"),
    media_type: Optional[str] = Query(
        None,
        description="Explicit media type hint: video | audio | image | text",
    ),
):
    """
    **Full pipeline:**
    1. Validate & persist the upload to a temp directory
    2. Detect media category (or use the hint)
    3. Run the appropriate analyser (OpenCV / Librosa / Pillow / text)
    4. Return authenticity score, threat level, radar dimensions, and details
    5. Clean up the temp file
    """
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided.")

    saved_path, detected_type = await save_upload(file)
    resolved_type = media_type or detected_type

    try:
        result = await analyze_media(
            path=saved_path,
            media_type=resolved_type,
            filename=file.filename,
        )
    except Exception as exc:
        logger.exception("Media analysis failed")
        raise HTTPException(status_code=500, detail=str(exc))
    finally:
        cleanup(saved_path)

    logger.info(
        f"[DETECT] {file.filename} → score={result.authenticity_score:.1f} "
        f"threat={result.threat_level} deepfake={result.is_deepfake}"
    )
    return result
