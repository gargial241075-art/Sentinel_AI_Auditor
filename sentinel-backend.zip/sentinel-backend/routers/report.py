"""
routers/report.py
──────────────────────────────────────────────────────────────────────────────
GET /report/certificate?job_id=<uuid>&entity_type=media&score=92.5&passed=true

Returns a signed IntegrityCertificate JSON.

In a production system you would look up the job from a database;
here we generate it on-the-fly from the query params, which is
sufficient for frontend integration testing.
"""
import logging
from typing import Literal, Optional

from fastapi import APIRouter, Query, HTTPException
from fastapi.responses import JSONResponse

from models.schemas import IntegrityCertificate, ErrorResponse
from services.certificate_service import build_certificate

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/report", tags=["Report"])


@router.get(
    "/certificate",
    response_model=IntegrityCertificate,
    summary="Generate / retrieve an Integrity Certificate for a completed job",
    responses={400: {"model": ErrorResponse}},
)
async def get_certificate(
    job_id: str = Query(..., description="UUID of the completed analysis job"),
    entity_type: Literal["media", "model"] = Query(
        "media", description="Type of entity audited"
    ),
    score: float = Query(..., ge=0, le=100, description="Primary quality score"),
    passed: bool = Query(..., description="Whether the audit passed"),
    filename: Optional[str] = Query(None, description="Original filename"),
):
    """
    Build and return a signed IntegrityCertificate.

    The certificate includes:
    - A unique `certificate_id`  (e.g. SNT-2026-A3F1)
    - A `validation_hash` for display in the UI
    - An HMAC-SHA256 `signed_payload` for server-side verification
    - An `expires_at` date (~14 months from now)
    """
    if not job_id.strip():
        raise HTTPException(status_code=400, detail="job_id must not be empty")

    cert = build_certificate(
        job_id=job_id,
        entity_type=entity_type,
        score=score,
        passed=passed,
        metadata={"filename": filename or "unknown"},
    )
    logger.info(f"[CERT] Issued {cert.certificate_id} for job {job_id} → {cert.status}")
    return cert


@router.post(
    "/verify",
    summary="Verify the integrity of an existing certificate",
    response_class=JSONResponse,
)
async def verify_certificate(body: IntegrityCertificate):
    """
    Re-sign the core fields of the submitted certificate and compare
    the result against `signed_payload`.  Returns a verification result.
    """
    from utils.hashing import sign_certificate as _sign

    core = {
        "certificate_id": body.certificate_id,
        "job_id": body.job_id,
        "entity_type": body.entity_type,
        "status": body.status,
        "score": body.metadata.get("score", 0),
        "issued_at": body.issued_at.isoformat(),
        "expires_at": body.expires_at.isoformat(),
    }
    expected = _sign(core)
    valid = expected == body.signed_payload

    return {
        "valid": valid,
        "certificate_id": body.certificate_id,
        "message": "Certificate is authentic." if valid else "Signature mismatch — certificate may be tampered.",
    }
