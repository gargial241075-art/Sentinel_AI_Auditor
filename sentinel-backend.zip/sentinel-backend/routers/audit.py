"""
routers/audit.py
──────────────────────────────────────────────────────────────────────────────
POST /audit/model
  Accepts a model file / dataset and returns a full compliance audit report.
"""
import logging

from fastapi import APIRouter, File, UploadFile, Form, HTTPException
from typing import Optional

from models.schemas import ModelAuditResponse, ErrorResponse
from services.model_auditor import audit_model
from utils.file_handler import save_upload, cleanup

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/audit", tags=["Audit"])


@router.post(
    "/model",
    response_model=ModelAuditResponse,
    summary="Audit an AI model or dataset for bias, safety, and performance",
    responses={
        400: {"model": ErrorResponse},
        413: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
)
async def audit_model_endpoint(
    file: UploadFile = File(..., description=".py / .csv / .json / .pkl / .txt model or dataset"),
    model_name: Optional[str] = Form(None, description="Human-readable model name"),
    deployment_env: Optional[str] = Form(None, description="e.g. production, staging"),
    focus_areas: Optional[str] = Form(
        None, description="Comma-separated focus areas: bias,safety,performance"
    ),
):
    """
    **Full pipeline:**
    1. Validate & persist the upload
    2. Route to the correct static analyser (CSV→dataset, .py→code, etc.)
    3. Build dimension scores and recommendations
    4. Return full ModelAuditResponse
    """
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided.")

    saved_path, _ = await save_upload(file)

    try:
        result = await audit_model(
            path=saved_path,
            filename=file.filename,
        )
    except Exception as exc:
        logger.exception("Model audit failed")
        raise HTTPException(status_code=500, detail=str(exc))
    finally:
        cleanup(saved_path)

    logger.info(
        f"[AUDIT] {file.filename} → bias={result.bias_score:.1f} "
        f"safety={result.safety_index:.1f} perf={result.performance_score:.1f} "
        f"grade={result.overall_grade} passed={result.audit_passed}"
    )
    return result
