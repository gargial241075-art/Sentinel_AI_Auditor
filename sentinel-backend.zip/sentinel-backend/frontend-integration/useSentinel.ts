/**
 * frontend-integration/useSentinel.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Drop this into src/hooks/useSentinel.ts in your Next.js project.
 *
 * Provides a single hook that manages:
 *  - File upload state
 *  - Real-time WebSocket log streaming
 *  - Detection / audit API calls
 *  - Certificate fetching
 *
 * Usage in your component:
 * ──────────────────────────
 *   const {
 *     runDetection, runAudit,
 *     isAnalyzing, logEntries, result, certificate,
 *     error, progress,
 *   } = useSentinel();
 *
 *   // Trigger analysis
 *   await runDetection(myFile, 'video');
 */

'use client';

import { useState, useRef, useCallback } from 'react';
import {
  SentinelAPI,
  MediaDetectionResult,
  ModelAuditResult,
  IntegrityCertificate,
  WSLogEntry,
  SentinelAPIError,
} from './sentinel-api';

export interface LogStep {
  id: string;
  timestamp: string;
  title: string;
  description: string;
  status: 'completed' | 'running' | 'pending' | 'alert' | 'queued';
  alertType?: 'red' | 'amber';
  alertText?: string;
}

interface SentinelState {
  isAnalyzing: boolean;
  progress: number;                         // 0-100
  logEntries: LogStep[];
  mediaResult: MediaDetectionResult | null;
  auditResult: ModelAuditResult | null;
  certificate: IntegrityCertificate | null;
  error: string | null;
}

function wsEntryToLogStep(entry: WSLogEntry, idx: number): LogStep {
  return {
    id: `${Date.now()}-${idx}`,
    timestamp: new Date(entry.timestamp).toLocaleTimeString('en-US', { hour12: false }),
    title: `[${entry.tag}]`,
    description: entry.message,
    status: entry.status as LogStep['status'],
    alertType: entry.alert_type ?? undefined,
    alertText: entry.alert_type ? entry.message : undefined,
  };
}

export function useSentinel() {
  const [state, setState] = useState<SentinelState>({
    isAnalyzing: false,
    progress: 0,
    logEntries: [],
    mediaResult: null,
    auditResult: null,
    certificate: null,
    error: null,
  });

  const wsRef = useRef<WebSocket | null>(null);
  const logIdxRef = useRef(0);

  const _reset = () => {
    wsRef.current?.close();
    logIdxRef.current = 0;
    setState(s => ({
      ...s,
      isAnalyzing: true,
      progress: 0,
      logEntries: [],
      mediaResult: null,
      auditResult: null,
      certificate: null,
      error: null,
    }));
  };

  const _openStream = (
    jobType: 'media' | 'model',
    mediaType: string,
  ): Promise<void> =>
    new Promise((resolve) => {
      wsRef.current = SentinelAPI.openLogStream(
        jobType,
        mediaType,
        (entry) => {
          const step = wsEntryToLogStep(entry, logIdxRef.current++);
          setState(s => ({
            ...s,
            progress: entry.progress ?? s.progress,
            logEntries: [...s.logEntries, step],
          }));
          if (entry.type === 'complete') resolve();
        },
        () => resolve(), // resolve even on WS error so API call still runs
      );
    });

  /**
   * Run deepfake detection on a media file.
   * Opens the WS log stream in parallel with the HTTP upload.
   */
  const runDetection = useCallback(async (
    file: File,
    mediaType: 'video' | 'audio' | 'image' | 'text' = 'video',
  ) => {
    _reset();
    try {
      // Start log stream and HTTP call in parallel
      const [_, result] = await Promise.all([
        _openStream('media', mediaType),
        SentinelAPI.detectMedia(file, mediaType),
      ]);

      const cert = await SentinelAPI.getCertificate(
        result.job_id,
        'media',
        result.authenticity_score,
        !result.is_deepfake,
        file.name,
      );

      setState(s => ({
        ...s,
        isAnalyzing: false,
        progress: 100,
        mediaResult: result,
        certificate: cert,
      }));
    } catch (err) {
      const msg = err instanceof SentinelAPIError ? err.detail : String(err);
      setState(s => ({ ...s, isAnalyzing: false, error: msg }));
    }
  }, []);

  /**
   * Run a compliance audit on a model / dataset file.
   */
  const runAudit = useCallback(async (
    file: File,
    opts?: { modelName?: string; deploymentEnv?: string },
  ) => {
    _reset();
    try {
      const [_, result] = await Promise.all([
        _openStream('model', 'model'),
        SentinelAPI.auditModel(file, opts),
      ]);

      const avgScore = (result.bias_score + result.safety_index + result.performance_score) / 3;
      const cert = await SentinelAPI.getCertificate(
        result.job_id,
        'model',
        avgScore,
        result.audit_passed,
        file.name,
      );

      setState(s => ({
        ...s,
        isAnalyzing: false,
        progress: 100,
        auditResult: result,
        certificate: cert,
      }));
    } catch (err) {
      const msg = err instanceof SentinelAPIError ? err.detail : String(err);
      setState(s => ({ ...s, isAnalyzing: false, error: msg }));
    }
  }, []);

  return {
    ...state,
    runDetection,
    runAudit,
  };
}
