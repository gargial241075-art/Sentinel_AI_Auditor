/**
 * lib/sentinel-api.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Drop this file into your Next.js project at  src/lib/sentinel-api.ts
 *
 * It provides typed wrappers for every Sentinel backend endpoint so you
 * never have to write raw fetch() calls in your components.
 *
 * Usage
 * ─────
 *   import { SentinelAPI } from '@/lib/sentinel-api';
 *
 *   // Deepfake detection
 *   const result = await SentinelAPI.detectMedia(file, 'video');
 *
 *   // AI model audit
 *   const audit = await SentinelAPI.auditModel(file);
 *
 *   // Integrity certificate
 *   const cert = await SentinelAPI.getCertificate(result.job_id, 'media', result.authenticity_score, !result.is_deepfake);
 *
 *   // Real-time WebSocket stream
 *   const ws = SentinelAPI.openLogStream('media', 'video', (entry) => {
 *     console.log(entry.message, entry.progress);
 *   });
 */

const BASE_URL = process.env.NEXT_PUBLIC_SENTINEL_API_URL ?? 'http://localhost:8000';
const WS_BASE  = BASE_URL.replace(/^http/, 'ws');

// ─── Types (mirrors backend Pydantic models) ──────────────────────────────────

export interface RadarDimensions {
  accuracy: number;
  safety: number;
  bias: number;
  privacy: number;
  transparency: number;
}

export interface MediaDetectionResult {
  job_id: string;
  file_name: string;
  media_type: 'video' | 'audio' | 'image' | 'text';
  authenticity_score: number;   // 0-100
  threat_level: 'Low' | 'Medium' | 'High';
  is_deepfake: boolean;
  confidence: number;
  radar_dimensions: RadarDimensions;
  analysis_details: Record<string, unknown>;
  processing_time_ms: number;
  timestamp: string;
}

export interface DimensionScore {
  score: number;
  status: 'Pass' | 'Warning' | 'Fail';
  details: string;
}

export interface ModelAuditResult {
  job_id: string;
  file_name: string;
  bias_score: number;
  safety_index: number;
  performance_score: number;
  overall_grade: 'A' | 'B' | 'C' | 'D' | 'F';
  dimension_breakdown: Record<string, DimensionScore>;
  recommendations: string[];
  audit_passed: boolean;
  processing_time_ms: number;
  timestamp: string;
}

export interface IntegrityCertificate {
  certificate_id: string;
  job_id: string;
  entity_type: 'media' | 'model';
  status: 'PASS' | 'FAIL' | 'PENDING';
  issued_at: string;
  expires_at: string;
  validation_hash: string;
  signed_payload: string;
  issuer: string;
  metadata: Record<string, unknown>;
}

export interface WSLogEntry {
  type: 'log' | 'progress' | 'complete' | 'error';
  step?: number;
  total_steps?: number;
  progress?: number;
  tag: 'SYS' | 'SEC' | 'AUD' | 'NET' | 'ML';
  message: string;
  timestamp: string;
  status: 'running' | 'completed' | 'pending' | 'alert' | 'queued';
  alert_type?: 'red' | 'amber';
}

// ─── Error class ──────────────────────────────────────────────────────────────

export class SentinelAPIError extends Error {
  constructor(
    public status: number,
    public detail: string,
  ) {
    super(`SentinelAPI [${status}]: ${detail}`);
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

async function _checkResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let detail = res.statusText;
    try { detail = (await res.json()).detail ?? detail; } catch {}
    throw new SentinelAPIError(res.status, detail);
  }
  return res.json() as Promise<T>;
}

// ─── API surface ─────────────────────────────────────────────────────────────

export const SentinelAPI = {
  /**
   * POST /detect/media
   * Upload a media file for deepfake analysis.
   */
  async detectMedia(
    file: File,
    mediaType?: 'video' | 'audio' | 'image' | 'text',
  ): Promise<MediaDetectionResult> {
    const form = new FormData();
    form.append('file', file);
    const url = new URL(`${BASE_URL}/detect/media`);
    if (mediaType) url.searchParams.set('media_type', mediaType);

    const res = await fetch(url.toString(), { method: 'POST', body: form });
    return _checkResponse<MediaDetectionResult>(res);
  },

  /**
   * POST /audit/model
   * Upload a model file or dataset for compliance auditing.
   */
  async auditModel(
    file: File,
    opts?: { modelName?: string; deploymentEnv?: string },
  ): Promise<ModelAuditResult> {
    const form = new FormData();
    form.append('file', file);
    if (opts?.modelName)     form.append('model_name', opts.modelName);
    if (opts?.deploymentEnv) form.append('deployment_env', opts.deploymentEnv);

    const res = await fetch(`${BASE_URL}/audit/model`, { method: 'POST', body: form });
    return _checkResponse<ModelAuditResult>(res);
  },

  /**
   * GET /report/certificate
   * Retrieve a signed Integrity Certificate for a completed job.
   */
  async getCertificate(
    jobId: string,
    entityType: 'media' | 'model',
    score: number,
    passed: boolean,
    filename?: string,
  ): Promise<IntegrityCertificate> {
    const url = new URL(`${BASE_URL}/report/certificate`);
    url.searchParams.set('job_id', jobId);
    url.searchParams.set('entity_type', entityType);
    url.searchParams.set('score', score.toString());
    url.searchParams.set('passed', passed.toString());
    if (filename) url.searchParams.set('filename', filename);

    const res = await fetch(url.toString());
    return _checkResponse<IntegrityCertificate>(res);
  },

  /**
   * WS /logs/stream
   * Open a WebSocket that streams real-time log entries.
   * Returns the WebSocket instance so the caller can close it.
   *
   * @param jobType   'media' | 'model'
   * @param mediaType 'video' | 'audio' | 'image' | 'text'  (for media jobs)
   * @param onMessage called for each WSLogEntry received
   * @param onError   optional error handler
   */
  openLogStream(
    jobType: 'media' | 'model',
    mediaType: string,
    onMessage: (entry: WSLogEntry) => void,
    onError?: (ev: Event) => void,
  ): WebSocket {
    const url = `${WS_BASE}/logs/stream?job_type=${jobType}&media_type=${mediaType}`;
    const ws = new WebSocket(url);

    ws.onmessage = (ev) => {
      try {
        const entry: WSLogEntry = JSON.parse(ev.data as string);
        onMessage(entry);
      } catch {
        console.warn('SentinelAPI WS — failed to parse message', ev.data);
      }
    };

    ws.onerror = (ev) => {
      console.error('SentinelAPI WS error', ev);
      onError?.(ev);
    };

    return ws;
  },

  /** GET /health — quick liveness check */
  async ping(): Promise<boolean> {
    try {
      const res = await fetch(`${BASE_URL}/health`);
      return res.ok;
    } catch {
      return false;
    }
  },
};
