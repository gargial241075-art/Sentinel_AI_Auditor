"""
services/model_auditor.py
──────────────────────────────────────────────────────────────────────────────
AI Model Integrity & Compliance Auditing.

Accepts: Python scripts (.py), serialised models (.pkl, .pt), datasets (.csv,
         .json) or plain text descriptions.

ARCHITECTURE
────────────
  audit_model()  ← public entry point
      │
      ├─ _audit_dataset()   pandas-based bias & distribution analysis
      ├─ _audit_python()    static code analysis for safety patterns
      └─ _audit_generic()   heuristic fallback for other file types

REPLACING MOCK LOGIC
────────────────────
  Each section marked # 🔄 REPLACE WITH REAL MODEL is where you plug in:
  - Fairlearn / AI Fairness 360 for bias metrics
  - Giskard / DeepChecks for safety/performance
  - Microsoft Responsible AI Toolbox for full compliance
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

import numpy as np

from models.schemas import (
    ModelAuditResponse, DimensionScore, WSLogEntry,
)

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════
#  Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def _noise(base: float, std: float = 5.0) -> float:
    return _clamp(base + float(np.random.normal(0, std)))


def _grade(avg: float) -> str:
    if avg >= 90: return "A"
    if avg >= 75: return "B"
    if avg >= 60: return "C"
    if avg >= 45: return "D"
    return "F"


def _dim_status(score: float) -> str:
    if score >= 75: return "Pass"
    if score >= 50: return "Warning"
    return "Fail"


# ═══════════════════════════════════════════════════════════════════════════
#  Dataset auditor (CSV / JSON)
# ═══════════════════════════════════════════════════════════════════════════

def _audit_dataset(path: Path) -> dict[str, Any]:
    """
    Loads a tabular dataset and checks for demographic imbalance,
    null rates, and distributional skew as proxy bias signals.
    """
    try:
        import pandas as pd  # type: ignore

        suffix = path.suffix.lower()
        if suffix == ".csv":
            df = pd.read_csv(path, nrows=5000)
        elif suffix in {".json", ".jsonl"}:
            df = pd.read_json(path, lines=suffix == ".jsonl")
        else:
            return _generic_scores()

        n_rows, n_cols = df.shape
        null_rate = float(df.isnull().mean().mean())
        numeric_cols = df.select_dtypes(include="number")
        skew_mean = float(numeric_cols.skew().abs().mean()) if not numeric_cols.empty else 0.0

        # 🔄 REPLACE WITH REAL MODEL (e.g. AI Fairness 360)
        bias_score = _noise(_clamp(100 - null_rate * 150 - skew_mean * 10), std=6)
        safety_score = _noise(_clamp(100 - null_rate * 100), std=5)
        perf_score = _noise(_clamp(85 - skew_mean * 5), std=7)

        return {
            "bias": bias_score,
            "safety": safety_score,
            "performance": perf_score,
            "details": {
                "rows": n_rows,
                "columns": n_cols,
                "null_rate": round(null_rate, 4),
                "mean_skewness": round(skew_mean, 4),
            },
        }
    except Exception:
        logger.exception("Dataset audit error")
        return _generic_scores()


# ═══════════════════════════════════════════════════════════════════════════
#  Python source auditor
# ═══════════════════════════════════════════════════════════════════════════

# Safety red flags in ML code
_SAFETY_PATTERNS = [
    r"eval\(", r"exec\(", r"__import__\(",
    r"subprocess\.", r"os\.system\(",
    r"pickle\.loads\(", r"yaml\.load\(",
    r"open\(.+['\"]w['\"]",           # arbitrary writes
]

def _audit_python(path: Path) -> dict[str, Any]:
    """
    Static analysis of Python model code for obvious safety anti-patterns.
    """
    try:
        src = path.read_text(errors="ignore")
        lines = src.splitlines()

        flag_count = sum(
            1 for pat in _SAFETY_PATTERNS
            if re.search(pat, src)
        )
        uses_fairness_lib = bool(re.search(r"fairlearn|aif360|fairness", src, re.I))
        has_logging = bool(re.search(r"logging\.|print\(", src))
        loc = len(lines)

        # 🔄 REPLACE WITH REAL MODEL
        safety_score = _noise(_clamp(100 - flag_count * 18), std=5)
        bias_score = _noise(80.0 if uses_fairness_lib else 55.0, std=8)
        perf_score = _noise(_clamp(60 + min(loc / 20, 30)), std=6)

        flags_found = [
            p for p in _SAFETY_PATTERNS if re.search(p, src)
        ]
        return {
            "bias": bias_score,
            "safety": safety_score,
            "performance": perf_score,
            "details": {
                "lines_of_code": loc,
                "safety_flags": flags_found,
                "uses_fairness_library": uses_fairness_lib,
                "has_logging": has_logging,
            },
        }
    except Exception:
        logger.exception("Python audit error")
        return _generic_scores()


# ═══════════════════════════════════════════════════════════════════════════
#  Generic fallback
# ═══════════════════════════════════════════════════════════════════════════

def _generic_scores() -> dict[str, Any]:
    return {
        "bias":        _noise(72.0, std=10),
        "safety":      _noise(78.0, std=8),
        "performance": _noise(70.0, std=10),
        "details":     {"note": "Generic heuristic scoring — no specialised analyser available"},
    }


# ═══════════════════════════════════════════════════════════════════════════
#  Dimension breakdown builder
# ═══════════════════════════════════════════════════════════════════════════

_DIM_DESCRIPTIONS = {
    "Demographic Parity":        "Measures outcome rate equality across protected groups.",
    "Semantic Alignment":        "Checks token-level semantic drift for different demographics.",
    "Cross-Regional Sensitivity":"Evaluates performance variance across regional language variants.",
    "PII Leakage Detection":     "Scans for personally identifiable information in model outputs.",
    "Prompt Injection Resistance":"Tests resilience against adversarial prompt injections.",
    "Adversarial Robustness":    "Perturbs inputs and measures output stability.",
    "Hallucination Threshold":   "Estimates factual grounding of generated responses.",
    "Reasoning Consistency":     "Checks logical coherence over multi-step reasoning chains.",
    "Throughput Efficiency":     "Measures tokens-per-second under typical load.",
}

def _build_dimensions(bias: float, safety: float, perf: float) -> dict[str, DimensionScore]:
    return {
        # Bias cluster
        "Demographic Parity": DimensionScore(
            score=_noise(bias, 4), status=_dim_status(_noise(bias, 4)),
            details=_DIM_DESCRIPTIONS["Demographic Parity"]
        ),
        "Semantic Alignment": DimensionScore(
            score=_noise(bias - 5, 5), status=_dim_status(_noise(bias - 5, 5)),
            details=_DIM_DESCRIPTIONS["Semantic Alignment"]
        ),
        "Cross-Regional Sensitivity": DimensionScore(
            score=_noise(bias + 3, 6), status=_dim_status(_noise(bias + 3, 6)),
            details=_DIM_DESCRIPTIONS["Cross-Regional Sensitivity"]
        ),
        # Safety cluster
        "PII Leakage Detection": DimensionScore(
            score=_noise(safety, 4), status=_dim_status(_noise(safety, 4)),
            details=_DIM_DESCRIPTIONS["PII Leakage Detection"]
        ),
        "Prompt Injection Resistance": DimensionScore(
            score=_noise(safety - 3, 5), status=_dim_status(_noise(safety - 3, 5)),
            details=_DIM_DESCRIPTIONS["Prompt Injection Resistance"]
        ),
        "Adversarial Robustness": DimensionScore(
            score=_noise(safety + 4, 7), status=_dim_status(_noise(safety + 4, 7)),
            details=_DIM_DESCRIPTIONS["Adversarial Robustness"]
        ),
        # Performance cluster
        "Hallucination Threshold": DimensionScore(
            score=_noise(perf, 5), status=_dim_status(_noise(perf, 5)),
            details=_DIM_DESCRIPTIONS["Hallucination Threshold"]
        ),
        "Reasoning Consistency": DimensionScore(
            score=_noise(perf + 2, 4), status=_dim_status(_noise(perf + 2, 4)),
            details=_DIM_DESCRIPTIONS["Reasoning Consistency"]
        ),
        "Throughput Efficiency": DimensionScore(
            score=_noise(perf - 5, 6), status=_dim_status(_noise(perf - 5, 6)),
            details=_DIM_DESCRIPTIONS["Throughput Efficiency"]
        ),
    }


# ═══════════════════════════════════════════════════════════════════════════
#  WebSocket log stream  (used by WebSocket router)
# ═══════════════════════════════════════════════════════════════════════════

_AUDIT_STEPS = [
    ("SYS", "Initialising Sentinel compliance protocol...", 0.4),
    ("ML",  "Loading model artefact into sandbox...", 0.7),
    ("ML",  "Demographic parity analysis (Bias)...", 0.9),
    ("ML",  "Semantic alignment check...", 0.8),
    ("SEC", "PII leakage scanning — tokenising outputs...", 1.0),
    ("SEC", "Prompt injection resistance tests (50 probes)...", 1.1),
    ("ML",  "Hallucination threshold evaluation...", 0.9),
    ("ML",  "Reasoning consistency benchmark...", 0.8),
    ("AUD", "Cross-referencing global safety standards...", 0.6),
    ("AUD", "Compiling compliance report...", 0.4),
]


async def stream_audit_logs(
    callback: Callable[[WSLogEntry], None],
) -> None:
    total = len(_AUDIT_STEPS)
    for i, (tag, msg, delay) in enumerate(_AUDIT_STEPS, 1):
        await asyncio.sleep(delay)
        callback(WSLogEntry(
            type="log", step=i, total_steps=total,
            progress=round(i / total * 90, 1),
            tag=tag,  # type: ignore[arg-type]
            message=msg, status="running",
        ))
    await asyncio.sleep(0.3)
    callback(WSLogEntry(
        type="complete", step=total, total_steps=total,
        progress=100.0, tag="SYS",
        message="Model compliance audit complete.",
        status="completed",
    ))


# ═══════════════════════════════════════════════════════════════════════════
#  Recommendations engine
# ═══════════════════════════════════════════════════════════════════════════

def _recommendations(bias: float, safety: float, perf: float) -> list[str]:
    recs: list[str] = []
    if bias < 70:
        recs.append("Introduce demographic parity constraints during fine-tuning.")
        recs.append("Audit training data for representation imbalance using AIF360.")
    if safety < 70:
        recs.append("Add output filtering layer for PII redaction before deployment.")
        recs.append("Run adversarial red-teaming sessions against the production endpoint.")
    if perf < 65:
        recs.append("Consider quantisation (INT8/FP16) to improve throughput without accuracy loss.")
        recs.append("Profile reasoning chains; reduce unnecessary CoT steps.")
    if not recs:
        recs.append("Model meets all core compliance thresholds. Schedule quarterly re-audit.")
    return recs


# ═══════════════════════════════════════════════════════════════════════════
#  Public entry point
# ═══════════════════════════════════════════════════════════════════════════

async def audit_model(
    path: Path,
    filename: str,
) -> ModelAuditResponse:
    t0 = time.perf_counter()

    suffix = path.suffix.lower()
    loop = asyncio.get_event_loop()

    if suffix in {".csv", ".json", ".jsonl"}:
        result = await loop.run_in_executor(None, _audit_dataset, path)
    elif suffix == ".py":
        result = await loop.run_in_executor(None, _audit_python, path)
    else:
        result = _generic_scores()

    bias  = _clamp(result["bias"])
    safety = _clamp(result["safety"])
    perf  = _clamp(result["performance"])
    avg   = (bias + safety + perf) / 3
    passed = avg >= 60.0

    elapsed_ms = int((time.perf_counter() - t0) * 1000)

    return ModelAuditResponse(
        job_id=str(uuid.uuid4()),
        file_name=filename,
        bias_score=round(bias, 2),
        safety_index=round(safety, 2),
        performance_score=round(perf, 2),
        overall_grade=_grade(avg),
        dimension_breakdown=_build_dimensions(bias, safety, perf),
        recommendations=_recommendations(bias, safety, perf),
        audit_passed=passed,
        processing_time_ms=elapsed_ms,
        timestamp=datetime.utcnow(),
    )
