"""
services/certificate_service.py
──────────────────────────────────────────────────────────────────────────────
Generates tamper-evident Integrity Certificates for both media and model jobs.
Certificates are signed with HMAC-SHA256 and carry an expiry date.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta
from typing import Literal

from core.config import get_settings
from models.schemas import IntegrityCertificate
from utils.hashing import (
    sign_certificate,
    generate_validation_hash,
    generate_certificate_id,
)

settings = get_settings()


def build_certificate(
    job_id: str,
    entity_type: Literal["media", "model"],
    score: float,
    passed: bool,
    metadata: dict,
) -> IntegrityCertificate:
    """
    Create and sign an IntegrityCertificate.

    Parameters
    ----------
    job_id       : UUID string of the analysis job
    entity_type  : "media" | "model"
    score        : primary quality score (0-100)
    passed       : whether the audit passed
    metadata     : arbitrary extra fields to embed
    """
    now = datetime.utcnow()
    expiry = now + timedelta(days=settings.CERT_VALIDITY_MONTHS * 30)

    cert_id = generate_certificate_id(job_id)
    val_hash = generate_validation_hash(job_id, score, now)

    core_payload = {
        "certificate_id": cert_id,
        "job_id": job_id,
        "entity_type": entity_type,
        "status": "PASS" if passed else "FAIL",
        "score": round(score, 4),
        "issued_at": now.isoformat(),
        "expires_at": expiry.isoformat(),
    }
    signature = sign_certificate(core_payload)

    return IntegrityCertificate(
        certificate_id=cert_id,
        job_id=job_id,
        entity_type=entity_type,
        status="PASS" if passed else "FAIL",
        issued_at=now,
        expires_at=expiry,
        validation_hash=val_hash,
        signed_payload=signature,
        metadata={**metadata, "score": round(score, 4)},
    )
