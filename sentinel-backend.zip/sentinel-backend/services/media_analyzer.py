"""
services/media_analyzer.py
──────────────────────────────────────────────────────────────────────────────
Deepfake & authenticity analysis for Video / Audio / Image / Text files.

ARCHITECTURE
────────────
  analyze_media()   ← public entry point called by the router
      │
      ├─ _analyze_video()   OpenCV frame sampling + mock neural scoring
      ├─ _analyze_audio()   Librosa spectral features + anomaly detection
      ├─ _analyze_image()   Pillow + pixel-level noise analysis
      └─ _analyze_text()    Heuristic pattern scoring

Each private analyser:
  1. Extracts real features from the file (OpenCV / Librosa / Pillow).
  2. Feeds those features into a mock scoring function.
  3. Returns a normalised result dict.

REPLACING MOCK LOGIC
────────────────────
  Search for the comment # 🔄 REPLACE WITH REAL MODEL and swap the
  scoring call with your trained model's predict() / inference().
"""
from __future__ import annotations

import asyncio
import logging
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, AsyncGenerator

import numpy as np

from models.schemas import MediaDetectionResponse, RadarDimensions, WSLogEntry

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
#  Internal helpers
# ═══════════════════════════════════════════════════════════════════════════

def _clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def _threat_level(score: float) -> str:
    if score >= 70:
        return "Low"
    if score >= 40:
        return "Medium"
    return "High"


def _add_noise(base: float, std: float = 6.0) -> float:
    return _clamp(base + float(np.random.normal(0, std)))


# ═══════════════════════════════════════════════════════════════════════════
#  Video analyser
# ═══════════════════════════════════════════════════════════════════════════

def _analyze_video(path: Path) -> dict[str, Any]:
    """
    Samples up to 30 frames, computes inter-frame variance, Laplacian
    sharpness, and a mock GAN-artefact score.
    """
    try:
        import cv2  # type: ignore

        cap = cv2.VideoCapture(str(path))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
        duration_s = total_frames / fps if fps else 0

        sampled_vars: list[float] = []
        sampled_sharp: list[float] = []
        step = max(1, total_frames // 30)

        for i in range(0, min(total_frames, 300), step):
            cap.set(cv2.CAP_PROP_POS_FRAMES, i)
            ret, frame = cap.read()
            if not ret:
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            sampled_vars.append(float(np.var(gray)))
            sampled_sharp.append(float(cv2.Laplacian(gray, cv2.CV_64F).var()))

        cap.release()

        mean_var = float(np.mean(sampled_vars)) if sampled_vars else 500.0
        mean_sharp = float(np.mean(sampled_sharp)) if sampled_sharp else 100.0

        # ── Heuristic scoring ─────────────────────────────────────────────
        # Low variance + low sharpness → suspect GAN output
        var_score = _clamp(mean_var / 20.0)          # 0-100 scale
        sharp_score = _clamp(mean_sharp / 50.0)      # 0-100 scale

        # 🔄 REPLACE WITH REAL MODEL ──────────────────────────────────────
        base_authenticity = (var_score * 0.45 + sharp_score * 0.55)
        base_authenticity = _add_noise(base_authenticity, std=8)

        eyeblink_rate = _add_noise(4.2, 1.5)         # BPM
        lip_sync_coherence = _add_noise(72.0, 10)

        details = {
            "frames_sampled": len(sampled_vars),
            "total_frames": total_frames,
            "duration_seconds": round(duration_s, 2),
            "fps": round(fps, 2),
            "mean_frame_variance": round(mean_var, 2),
            "mean_sharpness": round(mean_sharp, 2),
            "eyeblink_rate_bpm": round(eyeblink_rate, 1),
            "lip_sync_coherence": round(lip_sync_coherence, 1),
            "gan_artifact_probability": round(_clamp(100 - base_authenticity) / 100, 3),
        }
        alert = eyeblink_rate < 5.0

        return {
            "authenticity_score": base_authenticity,
            "alert": alert,
            "alert_message": "Low eyeblink rate detected — possible GAN artefact" if alert else None,
            "details": details,
        }

    except ImportError:
        logger.warning("OpenCV not installed — using fallback video scoring")
        return _fallback_score("video")
    except Exception as exc:
        logger.exception("Video analysis error")
        return _fallback_score("video")


# ═══════════════════════════════════════════════════════════════════════════
#  Audio analyser
# ═══════════════════════════════════════════════════════════════════════════

def _analyze_audio(path: Path) -> dict[str, Any]:
    """
    Loads audio with Librosa, extracts MFCCs, spectral centroid, and
    zero-crossing rate as proxy features for voice cloning detection.
    """
    try:
        import librosa  # type: ignore

        y, sr = librosa.load(str(path), sr=None, mono=True, duration=60.0)
        duration = librosa.get_duration(y=y, sr=sr)

        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        mfcc_std = float(np.std(mfcc))

        spectral_centroid = float(np.mean(librosa.feature.spectral_centroid(y=y, sr=sr)))
        zcr = float(np.mean(librosa.feature.zero_crossing_rate(y=y)))

        # ── Heuristic: cloned voices tend to have lower MFCC variance ────
        # 🔄 REPLACE WITH REAL MODEL
        mfcc_score = _clamp(mfcc_std * 2.5)
        spectral_score = _clamp((spectral_centroid / 4000) * 60)
        zcr_score = _clamp((1 - zcr * 5) * 80)

        base_authenticity = _add_noise(
            mfcc_score * 0.50 + spectral_score * 0.25 + zcr_score * 0.25,
            std=7,
        )
        details = {
            "duration_seconds": round(duration, 2),
            "sample_rate": sr,
            "mfcc_std": round(mfcc_std, 4),
            "spectral_centroid_hz": round(spectral_centroid, 1),
            "zero_crossing_rate": round(zcr, 5),
            "voice_clone_probability": round(_clamp(100 - base_authenticity) / 100, 3),
        }
        return {"authenticity_score": base_authenticity, "alert": False, "details": details}

    except ImportError:
        logger.warning("Librosa not installed — using fallback audio scoring")
        return _fallback_score("audio")
    except Exception:
        logger.exception("Audio analysis error")
        return _fallback_score("audio")


# ═══════════════════════════════════════════════════════════════════════════
#  Image analyser
# ═══════════════════════════════════════════════════════════════════════════

def _analyze_image(path: Path) -> dict[str, Any]:
    """
    Uses Pillow to measure colour noise, compression artefacts, and
    ELA (Error Level Analysis) as a basic deepfake signal.
    """
    try:
        from PIL import Image, ImageFilter  # type: ignore
        import io

        img = Image.open(path).convert("RGB")
        width, height = img.size

        # ELA: re-save at quality=90, compare pixel differences
        buffer = io.BytesIO()
        img.save(buffer, format="JPEG", quality=90)
        buffer.seek(0)
        ela_img = Image.open(buffer).convert("RGB")

        orig_arr = np.array(img, dtype=np.float32)
        ela_arr = np.array(ela_img, dtype=np.float32)
        ela_diff = np.abs(orig_arr - ela_arr).mean()

        # Edge density
        edges = img.filter(ImageFilter.FIND_EDGES)
        edge_mean = float(np.mean(np.array(edges)))

        # Colour variance
        color_std = float(np.std(orig_arr))

        # 🔄 REPLACE WITH REAL MODEL
        ela_score = _clamp(100 - ela_diff * 4)
        edge_score = _clamp(edge_mean * 1.5)
        color_score = _clamp(color_std / 2)

        base_authenticity = _add_noise(
            ela_score * 0.5 + edge_score * 0.3 + color_score * 0.2,
            std=6,
        )
        details = {
            "resolution": f"{width}x{height}",
            "ela_mean_diff": round(float(ela_diff), 4),
            "edge_density": round(edge_mean, 3),
            "color_std": round(color_std, 3),
            "face_swap_probability": round(_clamp(100 - base_authenticity) / 100, 3),
        }
        return {"authenticity_score": base_authenticity, "alert": False, "details": details}

    except ImportError:
        logger.warning("Pillow not installed — using fallback image scoring")
        return _fallback_score("image")
    except Exception:
        logger.exception("Image analysis error")
        return _fallback_score("image")


# ═══════════════════════════════════════════════════════════════════════════
#  Text analyser
# ═══════════════════════════════════════════════════════════════════════════

def _analyze_text(path: Path) -> dict[str, Any]:
    """
    Reads the text file and computes simple statistical signals
    (type-token ratio, sentence length distribution) as placeholders
    for a real LLM-detector model.
    """
    try:
        text = path.read_text(errors="ignore")
        words = text.split()
        word_count = len(words)
        unique_words = len(set(w.lower() for w in words))
        ttr = unique_words / word_count if word_count else 0

        sentences = [s.strip() for s in text.replace("!", ".").replace("?", ".").split(".") if s.strip()]
        avg_sentence_len = np.mean([len(s.split()) for s in sentences]) if sentences else 0

        # 🔄 REPLACE WITH REAL MODEL (e.g. GPT-2 detector)
        ttr_score = _clamp(ttr * 100 * 0.8)
        len_score = _clamp(min(avg_sentence_len * 4, 100))
        base_authenticity = _add_noise(ttr_score * 0.6 + len_score * 0.4, std=8)

        details = {
            "word_count": word_count,
            "unique_words": unique_words,
            "type_token_ratio": round(ttr, 4),
            "avg_sentence_length": round(float(avg_sentence_len), 1),
            "ai_generated_probability": round(_clamp(100 - base_authenticity) / 100, 3),
        }
        return {"authenticity_score": base_authenticity, "alert": False, "details": details}

    except Exception:
        logger.exception("Text analysis error")
        return _fallback_score("text")


# ═══════════════════════════════════════════════════════════════════════════
#  Fallback (no dependencies or error)
# ═══════════════════════════════════════════════════════════════════════════

def _fallback_score(media_type: str) -> dict[str, Any]:
    base = _add_noise(72.0, std=12)
    return {
        "authenticity_score": base,
        "alert": False,
        "details": {
            "note": f"Fallback scoring used for {media_type} — install optional deps for real analysis",
        },
    }


# ═══════════════════════════════════════════════════════════════════════════
#  Radar dimensions builder
# ═══════════════════════════════════════════════════════════════════════════

def _build_radar(authenticity: float) -> RadarDimensions:
    base = authenticity
    return RadarDimensions(
        accuracy=_add_noise(base, 5),
        safety=_add_noise(base + 5, 6),
        bias=_add_noise(base - 3, 7),
        privacy=_add_noise(base + 2, 5),
        transparency=_add_noise(base - 8, 8),
    )


# ═══════════════════════════════════════════════════════════════════════════
#  Real-time log stream  (used by WebSocket router)
# ═══════════════════════════════════════════════════════════════════════════

_VIDEO_STEPS = [
    ("SYS", "Initialising neural decomposition engine...", 0.5, "running"),
    ("ML",  "Frame-by-frame extraction started...", 0.8, "running"),
    ("ML",  "Eyeblink rate verification in progress...", 0.8, "running"),
    ("ML",  "Lip-sync phase-shift analysis running...", 1.0, "running"),
    ("SEC", "Deep spectral audio fingerprinting...", 0.8, "running"),
    ("AUD", "Sub-pixel artefact pattern scan...", 0.7, "running"),
    ("AUD", "Metadata authenticity verification...", 0.5, "running"),
    ("SYS", "Compiling audit report...", 0.3, "running"),
]
_AUDIO_STEPS = [
    ("SYS", "Loading audio waveform...", 0.4, "running"),
    ("ML",  "Extracting MFCC features (13 coefficients)...", 0.8, "running"),
    ("ML",  "Spectral centroid analysis...", 0.7, "running"),
    ("ML",  "Voice biometric fingerprint comparison...", 1.0, "running"),
    ("SEC", "Clone detection neural pass...", 0.8, "running"),
    ("AUD", "Encoding inconsistency scan...", 0.5, "running"),
]
_IMAGE_STEPS = [
    ("SYS", "Loading image into analysis pipeline...", 0.3, "running"),
    ("ML",  "ELA (Error Level Analysis) pass...", 0.6, "running"),
    ("ML",  "Facial landmark detection...", 0.8, "running"),
    ("ML",  "GAN artefact frequency scan...", 0.9, "running"),
    ("SEC", "Metadata EXIF forensics...", 0.4, "running"),
    ("AUD", "Edge density and noise profiling...", 0.4, "running"),
]
_TEXT_STEPS = [
    ("SYS", "Tokenising document...", 0.3, "running"),
    ("ML",  "Type-token ratio computation...", 0.4, "running"),
    ("ML",  "Semantic coherence scoring...", 0.7, "running"),
    ("ML",  "AI-generation probability pass...", 0.9, "running"),
    ("SEC", "Cross-referencing known LLM signatures...", 0.5, "running"),
]
_STEP_MAP = {"video": _VIDEO_STEPS, "audio": _AUDIO_STEPS,
             "image": _IMAGE_STEPS, "text": _TEXT_STEPS}


async def stream_analysis_logs(
    media_type: str,
    callback: Callable[[WSLogEntry], None],
) -> None:
    """
    Streams WSLogEntry objects to *callback* as analysis 'proceeds'.
    Called from the WebSocket router; callback sends JSON over the socket.
    """
    steps = _STEP_MAP.get(media_type, _VIDEO_STEPS)
    total = len(steps)

    for i, (tag, msg, delay, status) in enumerate(steps, start=1):
        await asyncio.sleep(delay)
        entry = WSLogEntry(
            type="log",
            step=i,
            total_steps=total,
            progress=round(i / total * 90, 1),   # 90% until final result
            tag=tag,  # type: ignore[arg-type]
            message=msg,
            status=status,  # type: ignore[arg-type]
        )
        callback(entry)

    # Final completion tick
    await asyncio.sleep(0.3)
    callback(WSLogEntry(
        type="complete",
        step=total,
        total_steps=total,
        progress=100.0,
        tag="SYS",
        message="Analysis complete. Integrity certificate issued.",
        status="completed",
    ))


# ═══════════════════════════════════════════════════════════════════════════
#  Public entry point
# ═══════════════════════════════════════════════════════════════════════════

async def analyze_media(
    path: Path,
    media_type: str,
    filename: str,
) -> MediaDetectionResponse:
    """
    Run the appropriate analyser in a thread-pool executor (non-blocking).
    Returns a fully populated MediaDetectionResponse.
    """
    t0 = time.perf_counter()

    loop = asyncio.get_event_loop()
    analyser_map: dict[str, Callable] = {
        "video": _analyze_video,
        "audio": _analyze_audio,
        "image": _analyze_image,
        "text":  _analyze_text,
    }
    analyser = analyser_map.get(media_type, _analyze_text)

    result = await loop.run_in_executor(None, analyser, path)

    score = _clamp(result["authenticity_score"])
    elapsed_ms = int((time.perf_counter() - t0) * 1000)

    return MediaDetectionResponse(
        job_id=str(uuid.uuid4()),
        file_name=filename,
        media_type=media_type,  # type: ignore[arg-type]
        authenticity_score=round(score, 2),
        threat_level=_threat_level(score),  # type: ignore[arg-type]
        is_deepfake=score < 50.0,
        confidence=round(_clamp(abs(score - 50) / 50) , 3),
        radar_dimensions=_build_radar(score),
        analysis_details=result.get("details", {}),
        processing_time_ms=elapsed_ms,
        timestamp=datetime.utcnow(),
    )
