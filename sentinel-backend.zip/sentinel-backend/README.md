# 🛡 Vault Sentinel — Python Backend

Production-ready FastAPI backend for the Vault Sentinel AI Audit & Deepfake Detection platform.  
Connects to your Next.js frontend running on `http://localhost:3000`.

---

## 📁 Folder Structure

```
sentinel-backend/
├── main.py                          # FastAPI app entry point
├── requirements.txt
├── .env.example                     # Copy → .env
│
├── core/
│   ├── config.py                    # Pydantic settings (reads .env)
│   └── logging.py                   # Structured logging setup
│
├── models/
│   └── schemas.py                   # All Pydantic request/response models
│
├── routers/
│   ├── detect.py                    # POST /detect/media
│   ├── audit.py                     # POST /audit/model
│   ├── logs.py                      # WS  /logs/stream
│   └── report.py                    # GET /report/certificate
│
├── services/
│   ├── media_analyzer.py            # OpenCV / Librosa / Pillow analysis
│   ├── model_auditor.py             # Scikit-learn / Pandas bias audit
│   └── certificate_service.py      # HMAC-signed certificate generation
│
├── utils/
│   ├── file_handler.py              # Upload validation, save, cleanup
│   └── hashing.py                   # HMAC-SHA256 signing, hash helpers
│
└── frontend-integration/
    ├── sentinel-api.ts              # Typed TypeScript API client
    └── useSentinel.ts               # React hook for components
```

---

## ⚡ Quick Start

### 1 · Clone / place the backend folder

```bash
# Place sentinel-backend/ next to your Next.js project
cd sentinel-backend
```

### 2 · Create a Python virtual environment

```bash
python -m venv .venv

# macOS / Linux
source .venv/bin/activate

# Windows (PowerShell)
.venv\Scripts\Activate.ps1
```

### 3 · Install dependencies

```bash
pip install -r requirements.txt
```

> **Note:** `opencv-python-headless` and `librosa` are optional — the server
> gracefully falls back to heuristic scoring if they aren't available.
> Install them for full feature extraction.

### 4 · Configure environment

```bash
cp .env.example .env
# Edit .env — at minimum change CERT_SECRET_KEY
```

### 5 · Run the development server

```bash
uvicorn main:app --reload --port 8000
```

Open **http://localhost:8000/docs** for the interactive Swagger UI.

---

## 🔌 Connecting to the Next.js Frontend

### Step 1 — Copy the integration files

```bash
cp frontend-integration/sentinel-api.ts  ../sentinel-frontend/src/lib/
cp frontend-integration/useSentinel.ts   ../sentinel-frontend/src/hooks/
```

### Step 2 — Add the API base URL to your Next.js `.env.local`

```env
NEXT_PUBLIC_SENTINEL_API_URL=http://localhost:8000
```

### Step 3 — Use the hook in your Detection Hub component

```tsx
// Inside DetectionHub.tsx (or your page.tsx)
import { useSentinel } from '@/hooks/useSentinel';

export function DetectionHub() {
  const {
    runDetection, runAudit,
    isAnalyzing, progress,
    logEntries,
    mediaResult, auditResult,
    certificate,
    error,
  } = useSentinel();

  const handleFileSelect = async (file: File, mediaType: 'video' | 'audio' | 'image' | 'text') => {
    await runDetection(file, mediaType);
  };

  // Map logEntries → your ProcessLog component's LogStep[] format
  // Map mediaResult → AuditAnalytics props
  // Map certificate → CertificationCard props
}
```

### Step 4 — Wire up Audit Analytics

After `runDetection` resolves:

```tsx
<AuditAnalytics
  authenticityScore={mediaResult?.authenticity_score ?? 0}
  threatLevel={mediaResult?.threat_level ?? 'Low'}
  isAnalyzing={isAnalyzing}
  radarData={{
    bias:         mediaResult?.radar_dimensions.bias ?? 20,
    accuracy:     mediaResult?.radar_dimensions.accuracy ?? 20,
    safety:       mediaResult?.radar_dimensions.safety ?? 20,
    transparency: mediaResult?.radar_dimensions.transparency ?? 20,
    privacy:      mediaResult?.radar_dimensions.privacy ?? 20,
  }}
/>
```

### Step 5 — Wire up the Certificate Card

```tsx
<CertificationCard
  status={certificate?.status.toLowerCase() as 'pass' | 'fail' | 'pending' ?? 'pending'}
  certificateId={certificate?.certificate_id}
  validationHash={certificate?.validation_hash}
  expiresDate={certificate
    ? new Date(certificate.expires_at).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
    : undefined}
/>
```

---

## 📡 API Reference

### `POST /detect/media`

Upload a media file for deepfake analysis.

**Form fields**
| Field | Type | Required |
|-------|------|----------|
| `file` | binary | ✅ |
| `media_type` | query param: `video\|audio\|image\|text` | optional |

**Response** — `MediaDetectionResponse`
```json
{
  "job_id": "3f7a…",
  "authenticity_score": 87.4,
  "threat_level": "Low",
  "is_deepfake": false,
  "confidence": 0.748,
  "radar_dimensions": { "accuracy": 88, "safety": 82, "bias": 75, "privacy": 85, "transparency": 70 },
  "analysis_details": { "frames_sampled": 30, "eyeblink_rate_bpm": 14.2, … }
}
```

---

### `POST /audit/model`

Upload a model file or dataset for compliance auditing.

**Form fields**
| Field | Type | Required |
|-------|------|----------|
| `file` | binary | ✅ |
| `model_name` | string | optional |
| `deployment_env` | string | optional |

**Response** — `ModelAuditResponse`
```json
{
  "bias_score": 87.0,
  "safety_index": 94.1,
  "performance_score": 78.3,
  "overall_grade": "B",
  "audit_passed": true,
  "dimension_breakdown": { "Demographic Parity": { "score": 89, "status": "Pass" }, … },
  "recommendations": ["Schedule quarterly re-audit."]
}
```

---

### `WS /logs/stream`

Real-time streaming of analysis log entries.

**Query params**
| Param | Values | Default |
|-------|--------|---------|
| `job_type` | `media` \| `model` | `media` |
| `media_type` | `video` \| `audio` \| `image` \| `text` | `video` |

**Message shape**
```json
{
  "type": "log",
  "step": 3,
  "total_steps": 8,
  "progress": 37.5,
  "tag": "ML",
  "message": "Eyeblink rate verification in progress...",
  "status": "running",
  "timestamp": "2026-05-08T09:34:21Z"
}
```

---

### `GET /report/certificate`

Generate a signed Integrity Certificate.

**Query params:** `job_id`, `entity_type`, `score`, `passed`, `filename`

**Response** — `IntegrityCertificate`
```json
{
  "certificate_id": "SNT-2026-A3F1",
  "status": "PASS",
  "validation_hash": "f7a9-201c-88e2-0050",
  "expires_at": "2027-08-01T00:00:00Z",
  "signed_payload": "a4b3c2…"
}
```

---

### `POST /report/verify`

Verify a certificate's HMAC signature. Pass the full `IntegrityCertificate` JSON body.

```json
{ "valid": true, "certificate_id": "SNT-2026-A3F1", "message": "Certificate is authentic." }
```

---

## 🔄 Replacing Mock Logic with Real Models

Each analyser file has comments marked **`# 🔄 REPLACE WITH REAL MODEL`**.

| File | Where to plug in |
|------|-----------------|
| `services/media_analyzer.py` · `_analyze_video()` | Your frame-based deepfake CNN (e.g. FaceForensics++ model) |
| `services/media_analyzer.py` · `_analyze_audio()` | Voice anti-spoofing model (e.g. AASIST, RawBoost) |
| `services/media_analyzer.py` · `_analyze_image()` | GAN detector (e.g. UniversalFakeDetect) |
| `services/model_auditor.py` · `_audit_dataset()` | AI Fairness 360 / Fairlearn metrics |
| `services/model_auditor.py` · `_audit_python()` | Bandit static analyser + Giskard |

**Example swap** (video CNN):
```python
# services/media_analyzer.py  ·  _analyze_video()
# 🔄 REPLACE WITH REAL MODEL ──────────────────────
import torch
model = torch.load("models/deepfake_detector.pt", map_location="cpu")
model.eval()
with torch.no_grad():
    frame_tensor = preprocess(sampled_frames)
    logits = model(frame_tensor)
    base_authenticity = float(torch.sigmoid(logits).mean() * 100)
```

---

## 🐳 Docker (Optional)

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

```bash
docker build -t sentinel-backend .
docker run -p 8000:8000 --env-file .env sentinel-backend
```

---

## 🔒 Security Notes

| Topic | Current State | Production Recommendation |
|-------|--------------|--------------------------|
| Auth | None (open API) | Add Bearer JWT via `python-jose` |
| HTTPS | HTTP (dev) | Terminate TLS at nginx / cloud LB |
| CERT_SECRET_KEY | Placeholder | Generate with `openssl rand -hex 32` |
| Temp files | `/tmp` | Use ephemeral cloud storage (S3/GCS) |
| Rate limiting | None | Add `slowapi` middleware |

---

## 📦 Key Dependencies

| Package | Purpose |
|---------|---------|
| `fastapi` | Async web framework |
| `uvicorn[standard]` | ASGI server with WebSocket support |
| `python-multipart` | File upload parsing |
| `opencv-python-headless` | Video frame analysis |
| `librosa` | Audio feature extraction |
| `Pillow` | Image analysis (ELA) |
| `scikit-learn` | Statistical scoring |
| `pandas` | Dataset bias analysis |
| `pydantic-settings` | Typed config from `.env` |
| `cryptography` | HMAC certificate signing |
