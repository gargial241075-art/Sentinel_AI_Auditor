"""
models/schemas.py — All request/response Pydantic models.
These are the contracts between the frontend and backend.
"""
from __future__ import annotations
from datetime import datetime
from typing import Literal, Optional
from pydantic import BaseModel, Field


# ═══════════════════════════════════════════════════════
#  Shared
# ═══════════════════════════════════════════════════════

class RadarDimensions(BaseModel):
    accuracy: float = Field(..., ge=0, le=100)
    safety: float   = Field(..., ge=0, le=100)
    bias: float     = Field(..., ge=0, le=100)
    privacy: float  = Field(..., ge=0, le=100)
    transparency: float = Field(..., ge=0, le=100)


# ═══════════════════════════════════════════════════════
#  /detect/media
# ═══════════════════════════════════════════════════════

class MediaDetectionResponse(BaseModel):
    job_id: str
    file_name: str
    media_type: Literal["video", "audio", "image", "text"]
    authenticity_score: float = Field(..., ge=0, le=100,
        description="0 = certain deepfake, 100 = certain authentic")
    threat_level: Literal["Low", "Medium", "High"]
    is_deepfake: bool
    confidence: float = Field(..., ge=0, le=1)
    radar_dimensions: RadarDimensions
    analysis_details: dict
    processing_time_ms: int
    timestamp: datetime


# ═══════════════════════════════════════════════════════
#  /audit/model
# ═══════════════════════════════════════════════════════

class AuditRequest(BaseModel):
    """Optional JSON body that can accompany a file upload."""
    model_name: Optional[str] = None
    deployment_env: Optional[str] = None
    focus_areas: Optional[list[str]] = None   # e.g. ["bias","safety"]


class DimensionScore(BaseModel):
    score: float = Field(..., ge=0, le=100)
    status: Literal["Pass", "Warning", "Fail"]
    details: str


class ModelAuditResponse(BaseModel):
    job_id: str
    file_name: str
    bias_score: float
    safety_index: float
    performance_score: float
    overall_grade: Literal["A", "B", "C", "D", "F"]
    dimension_breakdown: dict[str, DimensionScore]
    recommendations: list[str]
    audit_passed: bool
    processing_time_ms: int
    timestamp: datetime


# ═══════════════════════════════════════════════════════
#  /report/certificate
# ═══════════════════════════════════════════════════════

class IntegrityCertificate(BaseModel):
    certificate_id: str
    job_id: str
    entity_type: Literal["media", "model"]
    status: Literal["PASS", "FAIL", "PENDING"]
    issued_at: datetime
    expires_at: datetime
    validation_hash: str
    signed_payload: str          # HMAC-SHA256 of core fields
    issuer: str = "VAULT_SENTINEL / Secure_DC_04"
    metadata: dict


# ═══════════════════════════════════════════════════════
#  WebSocket messages
# ═══════════════════════════════════════════════════════

class WSLogEntry(BaseModel):
    type: Literal["log", "progress", "complete", "error"]
    step: Optional[int] = None
    total_steps: Optional[int] = None
    progress: Optional[float] = None   # 0-100
    tag: Literal["SYS", "SEC", "AUD", "NET", "ML"] = "SYS"
    message: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    status: Literal["running", "completed", "pending", "alert", "queued"] = "running"
    alert_type: Optional[Literal["red", "amber"]] = None


# ═══════════════════════════════════════════════════════
#  Error wrapper
# ═══════════════════════════════════════════════════════

class ErrorResponse(BaseModel):
    error: str
    detail: Optional[str] = None
    code: int
